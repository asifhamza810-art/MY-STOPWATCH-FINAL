import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import AuthModal from '../components/ui/AuthModal'

export default function SettingsPage() {
  const { user, profile, refreshMe, logout } = useAuth()
  const [preferredName, setPreferredName] = useState('')
  const [educationStage, setEducationStage] = useState('')
  const [city, setCity] = useState('Karachi')
  const [budget, setBudget] = useState('flexible')
  const [saving, setSaving] = useState(false)
  const [statusMsg, setStatusMsg] = useState(null)
  const [authModalOpen, setAuthModalOpen] = useState(false)

  useEffect(() => {
    if (profile) {
      setPreferredName(profile.preferredName || user?.displayName || '')
      setEducationStage(profile.educationStage || 'HSC Pre-Engineering')
      setCity(profile.city || 'Karachi')
      setBudget(profile.budgetPreference || 'flexible')
    } else if (user) {
      setPreferredName(user.displayName || '')
    }
  }, [profile, user])

  const handleSaveProfile = async (e) => {
    e.preventDefault()
    setSaving(true)
    setStatusMsg(null)
    try {
      await api('/profile', {
        method: 'PATCH',
        auth: true,
        body: {
          preferredName,
          educationStage,
          city,
          budgetPreference: budget,
        },
      })
      await refreshMe()
      setStatusMsg('✓ Profile preferences successfully updated!')
    } catch (err) {
      setStatusMsg(`Error: ${err.message}`)
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteAccount = async () => {
    const confirmation = prompt('Type DELETE to confirm permanently scheduling your account for deletion:')
    if (confirmation !== 'DELETE') return
    alert('Account deletion request registered in accordance with Acadiv data lifecycle policy.')
    logout()
  }

  if (!user) {
    return (
      <div style={{ maxWidth: '600px', margin: '60px auto', textAlign: 'center' }}>
        <div className="card" style={{ padding: '40px' }}>
          <h2>Account Settings</h2>
          <p style={{ margin: '14px 0 24px' }}>
            Please sign in to manage your student profile, academic preferences, and privacy controls.
          </p>
          <button type="button" className="btn btn-primary" onClick={() => setAuthModalOpen(true)}>
            Sign In Now
          </button>
        </div>
        {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
      </div>
    )
  }

  return (
    <div style={{ maxWidth: '780px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '32px' }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <span className="badge badge-cyan">Account & Preferences</span>
          <span className="badge badge-verified">Active Session</span>
        </div>
        <h1>Settings & Privacy</h1>
        <p style={{ fontSize: '0.95rem' }}>
          Manage your personal educational preferences, portfolio visibility, and account security.
        </p>
      </div>

      {statusMsg && (
        <div
          style={{
            padding: '12px 18px',
            borderRadius: 'var(--radius-md)',
            background: statusMsg.startsWith('✓') ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
            border: `1px solid ${statusMsg.startsWith('✓') ? '#10B981' : '#EF4444'}`,
            color: statusMsg.startsWith('✓') ? '#34D399' : '#F87171',
            fontSize: '0.9rem',
          }}
        >
          {statusMsg}
        </div>
      )}

      {/* Profile Form */}
      <div className="card" style={{ padding: '32px' }}>
        <h3 style={{ marginBottom: '20px' }}>Student Profile Details</h3>

        <form onSubmit={handleSaveProfile}>
          <div className="form-group">
            <label className="form-label">Email Address (Read-only)</label>
            <input
              type="text"
              className="form-input"
              value={user.email}
              disabled
              style={{ opacity: 0.7, cursor: 'not-allowed' }}
            />
          </div>

          <div className="form-group">
            <label className="form-label">Preferred / Display Name</label>
            <input
              type="text"
              className="form-input"
              value={preferredName}
              onChange={(e) => setPreferredName(e.target.value)}
              required
            />
          </div>

          <div className="grid-cols-2">
            <div className="form-group">
              <label className="form-label">Education Stage</label>
              <select
                className="form-select"
                value={educationStage}
                onChange={(e) => setEducationStage(e.target.value)}
              >
                <option value="Matriculation">Matriculation (Science)</option>
                <option value="HSC Pre-Engineering">Intermediate (Pre-Engineering)</option>
                <option value="HSC Pre-Medical">Intermediate (Pre-Medical)</option>
                <option value="HSC ICS">Intermediate (ICS)</option>
                <option value="HSC Commerce">Intermediate (Commerce)</option>
                <option value="DAE Technical">DAE (Associate Engineering)</option>
                <option value="A-Level">A-Level (Cambridge)</option>
                <option value="Undergraduate">Current Undergraduate</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">City</label>
              <input
                type="text"
                className="form-input"
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Budget Preference</label>
            <select
              className="form-select"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
            >
              <option value="subsidized">Public / Subsidized Merit (NED, KU: Rs 30k–60k/sem)</option>
              <option value="moderate">Moderate Private (Rs 80k–140k/sem)</option>
              <option value="flexible">Flexible / Tier-1 Private (FAST, IBA: Rs 180k+/sem)</option>
            </select>
          </div>

          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving...' : 'Save Profile Preferences'}
          </button>
        </form>
      </div>

      {/* Account Security & Deletion */}
      <div className="card" style={{ padding: '32px', borderColor: 'rgba(239, 68, 68, 0.25)' }}>
        <h3 style={{ color: '#F87171', marginBottom: '8px' }}>Danger Zone</h3>
        <p style={{ fontSize: '0.88rem', marginBottom: '20px' }}>
          Permanently delete your student account, assessment records, custom roadmaps, and vault evidence.
        </p>

        <button
          type="button"
          className="btn btn-outline"
          style={{ borderColor: 'rgba(239, 68, 68, 0.4)', color: '#EF4444' }}
          onClick={handleDeleteAccount}
        >
          Request Account Deletion
        </button>
      </div>
    </div>
  )
}
