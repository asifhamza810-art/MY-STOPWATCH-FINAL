import { useEffect, useState } from 'react'
import { useParams, useSearchParams, Link } from 'react-router-dom'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import AuthModal from '../components/ui/AuthModal'

export default function PortfolioPage() {
  const { username } = useParams()
  const [searchParams] = useSearchParams()
  const token = searchParams.get('token')
  const { user } = useAuth()

  const [portfolio, setPortfolio] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  // Edit mode for own profile
  const [isEditing, setIsEditing] = useState(false)
  const [editHeadline, setEditHeadline] = useState('')
  const [editBio, setEditBio] = useState('')
  const [editVisibility, setEditVisibility] = useState('public')
  const [saving, setSaving] = useState(false)

  const isOwnProfile = user && (!username || username === 'me' || username.toLowerCase() === user.displayName?.toLowerCase().replace(/\s+/g, ''))

  useEffect(() => {
    async function loadPortfolio() {
      setLoading(true)
      setError(null)
      try {
        if (isOwnProfile) {
          const res = await api('/portfolio/me', { auth: true })
          if (res.data) {
            setPortfolio(res.data)
            setEditHeadline(res.data.headline || '')
            setEditBio(res.data.biography || '')
            setEditVisibility(res.data.visibility || 'public')
          } else {
            // Need to initialize portfolio
            setIsEditing(true)
          }
        } else {
          let path = `/portfolio/${username}`
          if (token) path += `?token=${token}`
          const res = await api(path)
          setPortfolio(res.data)
        }
      } catch (err) {
        setError(err.message || 'Portfolio not found or access is restricted.')
      } finally {
        setLoading(false)
      }
    }
    loadPortfolio()
  }, [username, isOwnProfile, token])

  const handleSaveProfile = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      const uName = user.displayName?.toLowerCase().replace(/\s+/g, '') || 'student'
      const res = await api('/portfolio/me', {
        method: 'PUT',
        auth: true,
        body: {
          username: uName,
          headline: editHeadline,
          biography: editBio,
          visibility: editVisibility,
          selectedSkills: ['JavaScript', 'React', 'Node.js', 'Problem Solving'],
          educationRecords: [
            { institutionName: 'FAST-NUCES / NED', qualification: 'BS Computer Science', fieldOfStudy: 'Computing', startYear: 2024, endYear: 2028 },
          ],
        },
      })
      setPortfolio(res.data)
      setIsEditing(false)
    } catch (err) {
      alert(`Save error: ${err.message}`)
    } finally {
      setSaving(false)
    }
  }

  const handleCopyLink = () => {
    const url = window.location.href
    navigator.clipboard.writeText(url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handlePrintCv = () => {
    window.print()
  }

  if (loading) {
    return (
      <div style={{ maxWidth: '800px', margin: '40px auto' }}>
        <div className="skeleton" style={{ height: '140px', borderRadius: 'var(--radius-lg)', marginBottom: '20px' }} />
        <div className="skeleton" style={{ height: '300px', borderRadius: 'var(--radius-lg)' }} />
      </div>
    )
  }

  if (error) {
    return (
      <div style={{ maxWidth: '640px', margin: '60px auto', textAlign: 'center' }}>
        <div className="card" style={{ padding: '40px' }}>
          <div style={{ fontSize: '3rem', marginBottom: '12px' }}>🔒</div>
          <h2>Portfolio Private or Not Found</h2>
          <p style={{ margin: '12px 0 24px' }}>
            {error}
          </p>
          <Link to="/" className="btn btn-primary">
            Return to Acadiv Home
          </Link>
        </div>
      </div>
    )
  }

  if (isOwnProfile && isEditing) {
    return (
      <div style={{ maxWidth: '680px', margin: '30px auto' }}>
        <div className="card" style={{ padding: '36px' }}>
          <h2 style={{ marginBottom: '8px' }}>Configure Your Public Portfolio</h2>
          <p style={{ fontSize: '0.9rem', marginBottom: '24px' }}>
            Set your public headline, verified education history, and visibility rules.
          </p>

          <form onSubmit={handleSaveProfile}>
            <div className="form-group">
              <label className="form-label">Professional Headline</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. Aspiring Software Engineer | FSc Pre-Engineering to BS CS"
                value={editHeadline}
                onChange={(e) => setEditHeadline(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Biography & Objectives</label>
              <textarea
                className="form-textarea"
                rows={4}
                placeholder="Brief summary of your academic interests, coding projects, and career targets in Pakistan."
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Portfolio Privacy Mode</label>
              <select
                className="form-select"
                value={editVisibility}
                onChange={(e) => setEditVisibility(e.target.value)}
              >
                <option value="public">Public (Visible to anyone with your username)</option>
                <option value="unlisted">Unlisted (Accessible only via secret share link)</option>
                <option value="private">Private (Only visible to you)</option>
              </select>
            </div>

            <div style={{ display: 'flex', gap: '12px', marginTop: '20px' }}>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? 'Saving...' : 'Save & Publish Portfolio'}
              </button>
              {portfolio && (
                <button type="button" className="btn btn-secondary" onClick={() => setIsEditing(false)}>
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: '880px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Top Banner / Actions */}
      <div className="card card-glow" style={{ padding: '36px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '20px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <span className="badge badge-verified">Evidence-Backed Profile</span>
            <span className="badge badge-cyan">@{portfolio?.username || username || 'student'}</span>
          </div>

          <h1 style={{ fontSize: '2.2rem', marginBottom: '8px', color: '#FFFFFF' }}>
            {user?.displayName || portfolio?.displayName || 'Karachi Student'}
          </h1>
          <p style={{ fontSize: '1.05rem', color: '#38BDF8', fontWeight: 600, marginBottom: '12px' }}>
            {portfolio?.headline || 'Undergraduate Computing & Software Trainee'}
          </p>
          <p style={{ maxWidth: '600px', fontSize: '0.92rem', lineHeight: '1.6' }}>
            {portfolio?.biography || 'Passionate about full-stack engineering, algorithms, and verifiable projects. Currently following the Acadiv 3D roadmap.'}
          </p>
        </div>

        <div className="no-print" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <button type="button" className="btn btn-amber btn-sm" onClick={handlePrintCv}>
            📄 Export ATS-Friendly CV (PDF)
          </button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={handleCopyLink}>
            {copied ? '✓ Copied Share Link!' : '🔗 Copy Portfolio Link'}
          </button>
          {isOwnProfile && (
            <button type="button" className="btn btn-outline btn-sm" onClick={() => setIsEditing(true)}>
              ✏️ Edit Portfolio
            </button>
          )}
        </div>
      </div>

      {/* Verified Skills */}
      <div className="card">
        <h3 style={{ marginBottom: '16px' }}>Demonstrated Competencies</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
          {(portfolio?.selectedSkills?.length ? portfolio.selectedSkills : ['JavaScript ES6+', 'React.js', 'Node.js & Express', 'MongoDB Atlas', 'Git Version Control', 'DSA Fundamentals']).map((skill, idx) => (
            <span
              key={idx}
              style={{
                fontSize: '0.85rem',
                padding: '6px 14px',
                borderRadius: 'var(--radius-full)',
                background: 'rgba(2, 132, 199, 0.15)',
                border: '1px solid rgba(2, 132, 199, 0.3)',
                color: '#38BDF8',
                fontWeight: 600,
              }}
            >
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* Education & Qualifications */}
      <div className="card">
        <h3 style={{ marginBottom: '16px' }}>Academic Qualifications</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {(portfolio?.educationRecords?.length ? portfolio.educationRecords : [
            { institutionName: 'FAST-NUCES Karachi / NED', qualification: 'BS Computer Science', startYear: 2024, endYear: 2028 },
            { institutionName: 'Adamjee Govt. Science College, Karachi', qualification: 'HSC Pre-Engineering / ICS', startYear: 2022, endYear: 2024 },
          ]).map((edu, idx) => (
            <div key={idx} style={{ padding: '14px', background: 'rgba(11, 19, 43, 0.6)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <strong style={{ color: '#FFFFFF', fontSize: '1rem' }}>{edu.qualification}</strong>
                <span style={{ fontSize: '0.82rem', color: 'var(--text-dim)' }}>
                  {edu.startYear} – {edu.endYear || 'Present'}
                </span>
              </div>
              <div style={{ fontSize: '0.88rem', color: 'var(--text-muted)' }}>
                {edu.institutionName}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Artifact Evidence Records */}
      {portfolio?.artifacts?.length > 0 && (
        <div className="card">
          <h3 style={{ marginBottom: '16px' }}>Vault Evidence Artifacts</h3>
          <div className="grid-cols-2" style={{ gap: '14px' }}>
            {portfolio.artifacts.map((art) => (
              <div key={art._id} style={{ padding: '14px', background: 'rgba(11, 19, 43, 0.6)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                  <span className="badge badge-cyan">{art.category}</span>
                  <span style={{ fontSize: '0.78rem', color: '#10B981' }}>Verified</span>
                </div>
                <div style={{ fontWeight: 700, color: '#FFFFFF', marginBottom: '4px' }}>{art.title}</div>
                <p style={{ fontSize: '0.82rem', marginBottom: '10px' }}>{art.description}</p>
                {art.projectUrl && (
                  <a href={art.projectUrl} target="_blank" rel="noreferrer" style={{ fontSize: '0.8rem', color: '#38BDF8' }}>
                    View Code Repository ↗
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* CV Print Disclaimer */}
      <div style={{ fontSize: '0.82rem', color: 'var(--text-dim)', textAlign: 'center', marginTop: '10px' }}>
        Verified via Acadiv Evidence Architecture • Timestamp: {new Date().toLocaleDateString('en-PK')}
      </div>

      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
    </div>
  )
}
