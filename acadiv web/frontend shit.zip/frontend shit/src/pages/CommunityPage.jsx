import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import AuthModal from '../components/ui/AuthModal'

export default function CommunityPage() {
  const { user } = useAuth()
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedTag, setSelectedTag] = useState('')
  const [showNewModal, setShowNewModal] = useState(false)
  const [authModalOpen, setAuthModalOpen] = useState(false)

  // New post form state
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [tags, setTags] = useState('')
  const [category, setCategory] = useState('admissions')
  const [submitting, setSubmitting] = useState(false)
  const [statusMsg, setStatusMsg] = useState(null)

  // Reply state
  const [replyPostId, setReplyPostId] = useState(null)
  const [replyText, setReplyText] = useState('')
  const [replying, setReplying] = useState(false)

  const loadPosts = async () => {
    setLoading(true)
    try {
      let path = '/community/posts?'
      if (search) path += `q=${encodeURIComponent(search)}&`
      if (selectedTag) path += `tag=${encodeURIComponent(selectedTag)}&`
      const res = await api(path)
      setPosts(res.data || [])
    } catch (err) {
      console.error('Failed to load community posts:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const timer = setTimeout(loadPosts, 250)
    return () => clearTimeout(timer)
  }, [search, selectedTag])

  const handleCreatePost = async (e) => {
    e.preventDefault()
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    setSubmitting(true)
    setStatusMsg(null)
    try {
      const tagList = tags.split(',').map((t) => t.trim()).filter(Boolean)
      const res = await api('/community/posts', {
        method: 'POST',
        auth: true,
        body: { title, content, tags: tagList, category },
      })
      setStatusMsg(res.data?.message || 'Post submitted for moderation approval.')
      setTitle('')
      setContent('')
      setTags('')
      setShowNewModal(false)
      await loadPosts()
    } catch (err) {
      alert(`Error submitting post: ${err.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  const handleVote = async (postId) => {
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    try {
      const res = await api(`/community/posts/${postId}/vote`, {
        method: 'POST',
        auth: true,
      })
      setPosts((prev) =>
        prev.map((p) => (p._id === postId ? { ...p, upvoteCount: res.data.upvoteCount } : p))
      )
    } catch (err) {
      console.error('Vote failed:', err)
    }
  }

  const handleReply = async (postId) => {
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    if (!replyText.trim()) return
    setReplying(true)
    try {
      await api(`/community/posts/${postId}/replies`, {
        method: 'POST',
        auth: true,
        body: { content: replyText },
      })
      alert('Your reply was submitted and queued for moderation approval.')
      setReplyText('')
      setReplyPostId(null)
    } catch (err) {
      alert(`Reply failed: ${err.message}`)
    } finally {
      setReplying(false)
    }
  }

  const handleReport = async (postId) => {
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    const explanation = prompt('Please describe why you are reporting this content (e.g. spam, misinformation):')
    if (!explanation) return
    try {
      await api('/community/reports', {
        method: 'POST',
        auth: true,
        body: { targetType: 'post', targetId: postId, category: 'content_issue', explanation },
      })
      alert('Report logged for administrator review.')
    } catch (err) {
      alert(`Report failed: ${err.message}`)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <span className="badge badge-cyan">Moderated Student Hub</span>
            <span className="badge badge-verified">Peer & Senior Insights</span>
          </div>
          <h1>Karachi Student Community Hub</h1>
          <p style={{ maxWidth: '640px', fontSize: '0.95rem' }}>
            Ask questions, share entry test advice, and get answers verified by senior university peers and academic mentors.
          </p>
        </div>

        <button type="button" className="btn btn-primary" onClick={() => setShowNewModal(true)}>
          + Start New Discussion
        </button>
      </div>

      {statusMsg && (
        <div style={{ padding: '12px 18px', borderRadius: 'var(--radius-md)', background: 'rgba(16, 185, 129, 0.15)', border: '1px solid #10B981', color: '#34D399', fontSize: '0.9rem' }}>
          {statusMsg}
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="filter-bar">
        <div className="search-box">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search entry tests, FAST math, NED merit, ICS vs Pre-Eng..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          className="form-select"
          style={{ width: 'auto', minWidth: '160px' }}
          value={selectedTag}
          onChange={(e) => setSelectedTag(e.target.value)}
        >
          <option value="">All Topics</option>
          <option value="Admissions">Admissions</option>
          <option value="FAST">FAST-NUCES</option>
          <option value="EntryTest">Entry Tests</option>
          <option value="Intermediate">Intermediate & ICS</option>
          <option value="CareerGuidance">Career Guidance</option>
        </select>
      </div>

      {/* Posts List */}
      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {[1, 2, 3].map((i) => (
            <div key={i} className="card" style={{ height: '140px' }}>
              <div className="skeleton" style={{ height: '22px', width: '60%', marginBottom: '12px' }} />
              <div className="skeleton" style={{ height: '50px', width: '100%' }} />
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">💬</div>
          <h3 className="empty-title">No Discussions Found</h3>
          <p className="empty-text">Be the first to start a discussion thread or ask an entry test question.</p>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShowNewModal(true)}>
            Start Discussion
          </button>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
          {posts.map((post) => (
            <div key={post._id} className="card" style={{ padding: '24px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span className="badge badge-cyan">{post.category}</span>
                  <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)' }}>
                    Posted by <strong style={{ color: 'var(--text-main)' }}>{post.authorId?.displayName || 'Student'}</strong>
                    {post.authorId?.role === 'moderator' && (
                      <span className="badge badge-verified" style={{ marginLeft: '6px', fontSize: '0.7rem' }}>
                        Senior Mentor
                      </span>
                    )}
                  </span>
                </div>

                <button
                  type="button"
                  style={{ background: 'none', border: 'none', color: 'var(--text-dim)', fontSize: '0.78rem', cursor: 'pointer' }}
                  onClick={() => handleReport(post._id)}
                >
                  🚩 Report
                </button>
              </div>

              <h3 style={{ fontSize: '1.25rem', marginBottom: '10px', color: '#FFFFFF' }}>{post.title}</h3>
              <p style={{ fontSize: '0.92rem', marginBottom: '16px', lineHeight: '1.6' }}>{post.content}</p>

              {post.tags?.length > 0 && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '18px' }}>
                  {post.tags.map((tag) => (
                    <span
                      key={tag}
                      style={{
                        fontSize: '0.75rem',
                        padding: '2px 8px',
                        borderRadius: '4px',
                        background: 'rgba(255, 255, 255, 0.05)',
                        color: 'var(--text-muted)',
                      }}
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}

              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', borderTop: '1px solid rgba(255, 255, 255, 0.06)', paddingTop: '14px' }}>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => handleVote(post._id)}
                >
                  ▲ Upvote ({post.upvoteCount || 0})
                </button>

                <button
                  type="button"
                  className="btn btn-outline btn-sm"
                  onClick={() => setReplyPostId(replyPostId === post._id ? null : post._id)}
                >
                  {replyPostId === post._id ? 'Cancel Reply' : 'Reply to Thread'}
                </button>
              </div>

              {/* Reply Box */}
              {replyPostId === post._id && (
                <div style={{ marginTop: '16px', padding: '16px', background: 'rgba(11, 19, 43, 0.8)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
                  <textarea
                    className="form-textarea"
                    rows={3}
                    placeholder="Write a helpful answer or question..."
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                  />
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    style={{ marginTop: '10px' }}
                    disabled={replying}
                    onClick={() => handleReply(post._id)}
                  >
                    {replying ? 'Submitting...' : 'Post Reply'}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* New Post Modal */}
      {showNewModal && (
        <div className="modal-backdrop" onClick={() => setShowNewModal(false)}>
          <div className="modal-panel" style={{ maxWidth: '600px' }} onClick={(e) => e.stopPropagation()}>
            <button type="button" className="modal-close" onClick={() => setShowNewModal(false)}>
              ✕
            </button>

            <h3 style={{ marginBottom: '8px' }}>Start a Discussion</h3>
            <p style={{ fontSize: '0.88rem', marginBottom: '20px' }}>
              All posts are moderated to ensure safe, actionable academic discourse without spam or contact exposure.
            </p>

            <form onSubmit={handleCreatePost}>
              <div className="form-group">
                <label className="form-label">Discussion Title</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. Tips for NED University Pre-Admission Test"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Topic Category</label>
                <select
                  className="form-select"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option value="admissions">Admissions & Entrance Tests</option>
                  <option value="guidance">Career & Subject Guidance</option>
                  <option value="skills">Bootcamps & Skill Courses</option>
                  <option value="general">General Karachi Student Life</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Tags (comma-separated)</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. NED, EntryTest, Mathematics"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Discussion Content</label>
                <textarea
                  className="form-textarea"
                  rows={4}
                  placeholder="Explain your question or insight with clear context..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  required
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                style={{ width: '100%', marginTop: '10px' }}
                disabled={submitting}
              >
                {submitting ? 'Submitting...' : 'Submit Discussion'}
              </button>
            </form>
          </div>
        </div>
      )}

      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
    </div>
  )
}
