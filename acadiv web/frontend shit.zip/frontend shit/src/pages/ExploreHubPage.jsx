import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'

export default function ExploreHubPage() {
  const { user } = useAuth()
  const [stats, setStats] = useState({ institutions: 25, firms: 6, events: 6, careers: 15 })
  const [featuredFirm, setFeaturedFirm] = useState(null)
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadHubData() {
      try {
        const [instRes, firmsRes, eventsRes, careersRes] = await Promise.all([
          api('/institutions?limit=100'),
          api('/skill-firms'),
          api('/events?limit=4'),
          api('/careers'),
        ])

        setStats({
          institutions: instRes.data?.length || 25,
          firms: firmsRes.data?.length || 6,
          events: eventsRes.data?.length || 6,
          careers: careersRes.data?.length || 15,
        })

        if (firmsRes.data?.length) {
          setFeaturedFirm(firmsRes.data[0]) // Jawan Pakistan is guaranteed #1
        }
        setEvents(eventsRes.data || [])
      } catch (err) {
        console.error('Failed to load explorer hub data:', err)
      } finally {
        setLoading(false)
      }
    }
    loadHubData()
  }, [])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '36px' }}>
      {/* Welcome Banner */}
      <div
        className="card"
        style={{
          padding: '36px',
          background: 'linear-gradient(135deg, var(--surface) 0%, var(--surface-alt) 100%)',
          border: '1.5px solid var(--border)',
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <span className="badge badge-verified" style={{ marginBottom: '8px' }}>
              Student Workspace
            </span>
            <h1 style={{ fontSize: '2.4rem', marginBottom: '8px' }}>
              Welcome back, {user?.displayName?.split(' ')[0] || 'Student'}
            </h1>
            <p style={{ maxWidth: '640px', fontSize: '1rem' }}>
              Track verified Karachi college admissions, explore accredited engineering and medical faculties, and build your interactive pathway roadmap.
            </p>
          </div>

          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <Link to="/assessment" className="btn btn-teal">
              🎯 Take RIASEC Test
            </Link>
            <Link to="/roadmap" className="btn btn-secondary">
              🗺️ 3D Roadmap
            </Link>
          </div>
        </div>

        {/* Live Aggregates */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: '16px',
            marginTop: '32px',
          }}
        >
          <div style={{ padding: '16px 20px', background: 'var(--surface)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--forest)', fontFamily: 'var(--font-display)' }}>
              {stats.institutions}
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Karachi Institutions</div>
          </div>

          <div style={{ padding: '16px 20px', background: 'var(--surface)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--teal)', fontFamily: 'var(--font-display)' }}>
              {stats.firms}
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Verified Skill Firms</div>
          </div>

          <div style={{ padding: '16px 20px', background: 'var(--surface)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--coral)', fontFamily: 'var(--font-display)' }}>
              {stats.events}
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Campus Opportunities</div>
          </div>

          <div style={{ padding: '16px 20px', background: 'var(--surface)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
            <div style={{ fontSize: '1.8rem', fontWeight: 800, color: 'var(--violet)', fontFamily: 'var(--font-display)' }}>
              {stats.careers}
            </div>
            <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Documented Careers</div>
          </div>
        </div>
      </div>

      {/* Navigation Quick Access Modules */}
      <div>
        <h2 style={{ fontSize: '1.6rem', marginBottom: '18px' }}>Platform Navigation</h2>
        <div className="grid-cols-3">
          <Link to="/assessment" className="card" style={{ padding: '24px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🎯</div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>RIASEC Assessment</h3>
            <p style={{ fontSize: '0.9rem' }}>
              Adaptive 15–20 question diagnostic engine scored across 6 Holland dimensions with auditable reason traces.
            </p>
          </Link>

          <Link to="/roadmap" className="card" style={{ padding: '24px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🗺️</div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>3D Career Canvas</h3>
            <p style={{ fontSize: '0.9rem' }}>
              Interactive WebGL pathway canvas modeling multi-year timelines, semester budgets, and entrance test milestones.
            </p>
          </Link>

          <Link to="/institutions" className="card" style={{ padding: '24px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🏛️</div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>Karachi Institutions</h3>
            <p style={{ fontSize: '0.9rem' }}>
              Broad directory spanning NED, IBA, FAST, KU, DJ Science, Adamjee College, GCT, and STEVTA polytechnics.
            </p>
          </Link>

          <Link to="/skills" className="card" style={{ padding: '24px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>⚡</div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>Skill Bootcamps</h3>
            <p style={{ fontSize: '0.9rem' }}>
              Jawan Pakistan featured courses in Agentic AI and Flutter, alongside SMIT, Bano Qabil, and Aptech.
            </p>
          </Link>

          <Link to="/bulletin" className="card" style={{ padding: '24px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>📅</div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>Campus Bulletin</h3>
            <p style={{ fontSize: '0.9rem' }}>
              Zero-chat event discovery for hackathons, declamations, MUNs, and student exhibitions with automatic expiry.
            </p>
          </Link>

          <Link to="/vault" className="card" style={{ padding: '24px' }}>
            <div style={{ fontSize: '2rem', marginBottom: '12px' }}>📁</div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '6px' }}>Artifact Vault</h3>
            <p style={{ fontSize: '0.9rem' }}>
              Secure student-owned evidence repository for GitHub links, research, certificates, and ATS CV generation.
            </p>
          </Link>
        </div>
      </div>

      {/* Featured Jawan Pakistan Spotlight */}
      {featuredFirm && (
        <div
          className="card"
          style={{
            padding: '32px',
            background: 'linear-gradient(135deg, var(--surface) 0%, var(--surface-alt) 100%)',
            border: '1.5px solid var(--border)',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '12px', marginBottom: '12px' }}>
            <span className="badge badge-featured">
              ★ {featuredFirm.featuredLabel || 'Acadiv Featured Placement'}
            </span>
            <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              📍 {featuredFirm.campusArea}
            </span>
          </div>

          <h3 style={{ fontSize: '1.6rem', marginBottom: '8px' }}>{featuredFirm.name}</h3>
          <p style={{ maxWidth: '780px', fontSize: '0.95rem', marginBottom: '20px' }}>
            {featuredFirm.description}
          </p>

          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <Link to="/skills" className="btn btn-primary btn-sm">
              View Verified Courses & Fees →
            </Link>
            {featuredFirm.website && (
              <a href={featuredFirm.website} target="_blank" rel="noreferrer" className="btn btn-outline btn-sm">
                Official Portal ↗
              </a>
            )}
          </div>
        </div>
      )}

      {/* Active Bulletin Opportunities */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2 style={{ fontSize: '1.6rem' }}>Upcoming Campus Opportunities</h2>
          <Link to="/bulletin" className="btn btn-outline btn-sm">
            View All Bulletin Events →
          </Link>
        </div>

        <div className="grid-cols-2" style={{ gap: '18px' }}>
          {events.slice(0, 4).map((ev) => (
            <div key={ev._id} className="card" style={{ padding: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span className="badge badge-verified">{ev.category}</span>
                <span style={{ fontSize: '0.82rem', color: 'var(--forest)', fontWeight: 600 }}>Active</span>
              </div>
              <h4 style={{ fontSize: '1.15rem', marginBottom: '6px' }}>{ev.title}</h4>
              <p style={{ fontSize: '0.88rem', marginBottom: '12px' }}>{ev.description}</p>
              <div style={{ fontSize: '0.82rem', color: 'var(--text-dim)', marginBottom: '14px' }}>
                📍 {ev.venue || ev.campusArea} • Host: {ev.organizer}
              </div>
              <Link to="/bulletin" className="btn btn-secondary btn-sm" style={{ width: '100%' }}>
                View Registration Details
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

