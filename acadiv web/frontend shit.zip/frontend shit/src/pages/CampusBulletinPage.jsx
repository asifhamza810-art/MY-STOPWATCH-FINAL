import { useEffect, useState } from 'react'
import { api } from '../lib/api'

export default function CampusBulletinPage() {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [category, setCategory] = useState('')
  const [search, setSearch] = useState('')

  useEffect(() => {
    async function loadEvents() {
      setLoading(true)
      try {
        let path = '/events?limit=50'
        if (category) path += `&category=${encodeURIComponent(category)}`
        if (search) path += `&q=${encodeURIComponent(search)}`
        const res = await api(path)
        setEvents(res.data || [])
      } catch (err) {
        console.error('Failed to load bulletin events:', err)
      } finally {
        setLoading(false)
      }
    }
    const timer = setTimeout(loadEvents, 250)
    return () => clearTimeout(timer)
  }, [category, search])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <span className="badge badge-verified">Zero-Chat Discovery</span>
          <span className="badge badge-cyan">Automated Expiry</span>
        </div>
        <h1>Karachi Campus Opportunity Bulletin</h1>
        <p style={{ maxWidth: '640px', fontSize: '0.95rem' }}>
          Verified inter-university competitions, hackathons, MUNs, workshops, and student exhibitions across Karachi campuses.
        </p>
      </div>

      {/* Filter Bar */}
      <div className="filter-bar">
        <div className="search-box">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search Procom, IBAMUN, Robotics, Sentec..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          className="form-select"
          style={{ width: 'auto', minWidth: '160px' }}
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">All Categories</option>
          <option value="hackathon">Hackathons & Coding</option>
          <option value="mun">MUNs & Diplomacy</option>
          <option value="workshop">Technical Workshops</option>
          <option value="exhibition">Exhibitions & Expos</option>
          <option value="competition">Competitions</option>
        </select>
      </div>

      {/* Events Grid */}
      {loading ? (
        <div className="grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="card" style={{ height: '240px' }}>
              <div className="skeleton" style={{ height: '24px', width: '50%', marginBottom: '14px' }} />
              <div className="skeleton" style={{ height: '60px', width: '100%', marginBottom: '14px' }} />
              <div className="skeleton" style={{ height: '36px', width: '100%' }} />
            </div>
          ))}
        </div>
      ) : events.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📅</div>
          <h3 className="empty-title">No Active Events Right Now</h3>
          <p className="empty-text">
            Events automatically expire after their registration deadline passes to avoid outdated student listings.
          </p>
        </div>
      ) : (
        <div className="grid-cols-2" style={{ gap: '20px' }}>
          {events.map((ev) => {
            const startDate = ev.startsAt ? new Date(ev.startsAt).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' }) : 'TBD'
            const deadline = ev.registrationDeadline ? new Date(ev.registrationDeadline).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' }) : 'Open'

            return (
              <div key={ev._id} className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                    <span className="badge badge-cyan">{ev.category}</span>
                    <span style={{ fontSize: '0.8rem', color: '#10B981', fontWeight: 600 }}>
                      Format: {ev.format?.toUpperCase()}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '1.25rem', marginBottom: '8px', color: '#FFFFFF' }}>
                    {ev.title}
                  </h3>

                  <div style={{ fontSize: '0.85rem', color: '#38BDF8', fontWeight: 600, marginBottom: '12px' }}>
                    Organizer: {ev.organizer} ({ev.hostingInstitution})
                  </div>

                  <p style={{ fontSize: '0.9rem', marginBottom: '16px' }}>
                    {ev.description}
                  </p>

                  <div style={{ background: 'rgba(11, 19, 43, 0.6)', padding: '14px', borderRadius: 'var(--radius-md)', fontSize: '0.85rem', marginBottom: '18px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Event Date:</span>
                      <strong>{startDate}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Reg. Deadline:</span>
                      <strong style={{ color: '#FCD34D' }}>{deadline}</strong>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                      <span style={{ color: 'var(--text-muted)' }}>Venue / Location:</span>
                      <span>{ev.venue || ev.campusArea || 'Karachi'}</span>
                    </div>
                    {ev.feeNote && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '6px', paddingTop: '6px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                        <span style={{ color: 'var(--text-muted)' }}>Fee & Prizes:</span>
                        <span style={{ color: '#34D399', fontWeight: 600 }}>{ev.feeNote}</span>
                      </div>
                    )}
                  </div>
                </div>

                {ev.registrationLink && (
                  <a
                    href={ev.registrationLink}
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-primary"
                    style={{ width: '100%' }}
                  >
                    Official Registration Portal ↗
                  </a>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

