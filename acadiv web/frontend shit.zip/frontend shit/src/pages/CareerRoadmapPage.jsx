import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import CareerCanvas3D from '../components/roadmap/CareerCanvas3D'
import AuthModal from '../components/ui/AuthModal'

const DEFAULT_MILESTONES = [
  {
    _id: 'm1',
    title: 'Stage 1: Intermediate / A-Levels Foundations',
    description: 'Excel in Mathematics, Physics, and Computer Science fundamentals during HSC (Pre-Engineering/ICS) or A-Levels. Maintain above 65% aggregate for university eligibility.',
    status: 'done',
    estimatedMonths: 24,
    estimatedBudgetPkr: 80000,
    budgetAssumption: 'College tuition + books',
    skills: ['Mathematics', 'Physics', 'Programming Logic'],
    prerequisites: ['Matriculation Science (60%+) or O-Levels'],
    isDecisionPoint: false,
    tradeoffs: 'Pre-Engineering keeps engineering open; ICS focuses purely on computing.',
  },
  {
    _id: 'm2',
    title: 'Stage 2: University Entry Examination Success',
    description: 'Prepare specifically for FAST NU, NED, or IBA entry tests. Practice Advanced Mathematics, Analytical Reasoning, and speed-solving.',
    status: 'in_progress',
    estimatedMonths: 4,
    estimatedBudgetPkr: 15000,
    budgetAssumption: 'Test registrations & practice materials',
    skills: ['Speed Math', 'Analytical Logic', 'English Comprehension'],
    prerequisites: ['FSc Part 1 / A-Levels results'],
    isDecisionPoint: true,
    tradeoffs: 'Public (NED) offers subsidized fees; Private (FAST/IBA) offers higher campus placement velocity.',
  },
  {
    _id: 'm3',
    title: 'Stage 3: BS CS / SE Core Foundations & Real Coding',
    description: 'Master Object-Oriented Programming (OOP), Data Structures & Algorithms (DSA), Operating Systems, and Relational Databases at university.',
    status: 'planned',
    estimatedMonths: 24,
    estimatedBudgetPkr: 400000,
    budgetAssumption: 'First 2 years university tuition',
    skills: ['C++', 'Data Structures', 'OOP', 'SQL'],
    prerequisites: ['Successful university admission'],
    isDecisionPoint: false,
    tradeoffs: 'Focusing on deep DSA vs quick freelance web development.',
  },
  {
    _id: 'm4',
    title: 'Stage 4: Practical Specialization & Production Portfolio',
    description: 'Build 3–4 full-stack deployed web or mobile apps. Contribute to open source, participate in Procom hackathons, and link repositories in your Artifact Vault.',
    status: 'planned',
    estimatedMonths: 12,
    estimatedBudgetPkr: 20000,
    budgetAssumption: 'Hosting & skill training fees (Jawan Pakistan / SMIT)',
    skills: ['React', 'Node.js', 'Git', 'REST APIs', 'Cloud Deployment'],
    prerequisites: ['DSA fundamentals'],
    isDecisionPoint: true,
    tradeoffs: 'Freelancing vs Open Source vs AI specialization.',
  },
  {
    _id: 'm5',
    title: 'Stage 5: Industry Internship & Junior Role Placement',
    description: 'Secure summer engineering internships at Karachi software houses, venture-backed startups (e.g. Careem, Bazaar, Retailo, VentureDive), or remote global companies.',
    status: 'planned',
    estimatedMonths: 6,
    estimatedBudgetPkr: 0,
    budgetAssumption: 'Paid internship stipend (PKR 25,000–60,000/mo)',
    skills: ['System Design', 'Code Reviews', 'Team Collaboration'],
    prerequisites: ['Verified GitHub repository in Artifact Vault'],
    isDecisionPoint: false,
    tradeoffs: 'Local startup experience vs MNC training track.',
  },
]

export default function CareerRoadmapPage() {
  const { user } = useAuth()
  const [careers, setCareers] = useState([])
  const [selectedCareer, setSelectedCareer] = useState('software-engineer')
  const [milestones, setMilestones] = useState(DEFAULT_MILESTONES)
  const [selectedNode, setSelectedNode] = useState(DEFAULT_MILESTONES[1])
  const [activeTab, setActiveTab] = useState('3d') // '3d' | 'list'
  const [savedRoadmapId, setSavedRoadmapId] = useState(null)
  const [saving, setSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState(null)
  const [authModalOpen, setAuthModalOpen] = useState(false)

  // Load careers and any saved user roadmaps
  useEffect(() => {
    async function loadCareersAndRoadmap() {
      try {
        const cRes = await api('/careers')
        setCareers(cRes.data || [])

        if (user) {
          const rRes = await api('/roadmaps', { auth: true })
          if (rRes.data && rRes.data.length > 0) {
            const latest = rRes.data[0]
            setSavedRoadmapId(latest._id)
            if (latest.milestones && latest.milestones.length > 0) {
              setMilestones(latest.milestones)
              setSelectedNode(latest.milestones[0])
            }
          }
        }
      } catch (err) {
        console.error('Failed to load roadmap data:', err)
      }
    }
    loadCareersAndRoadmap()
  }, [user])

  // Calculate totals
  const totalMonths = milestones.reduce((sum, m) => sum + (Number(m.estimatedMonths) || 0), 0)
  const totalBudget = milestones.reduce((sum, m) => sum + (Number(m.estimatedBudgetPkr) || 0), 0)
  const completedCount = milestones.filter((m) => m.status === 'done').length

  const handleUpdateStatus = (id, newStatus) => {
    setMilestones((prev) =>
      prev.map((m) => (m._id === id || m.id === id ? { ...m, status: newStatus } : m))
    )
    if (selectedNode && (selectedNode._id === id || selectedNode.id === id)) {
      setSelectedNode((prev) => ({ ...prev, status: newStatus }))
    }
  }

  const handleSaveRoadmap = async () => {
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    setSaving(true)
    setSaveMessage(null)
    try {
      if (savedRoadmapId) {
        await api(`/roadmaps/${savedRoadmapId}`, {
          method: 'PATCH',
          auth: true,
          body: {
            title: `Roadmap for ${selectedCareer}`,
            milestones,
            timelineAssumptions: `Estimated total ${totalMonths} months`,
            budgetAssumptions: `Estimated total PKR ${totalBudget.toLocaleString()}`,
          },
        })
      } else {
        const res = await api('/roadmaps', {
          method: 'POST',
          auth: true,
          body: {
            title: `Roadmap for ${selectedCareer}`,
            milestones,
            timelineAssumptions: `Estimated total ${totalMonths} months`,
            budgetAssumptions: `Estimated total PKR ${totalBudget.toLocaleString()}`,
          },
        })
        setSavedRoadmapId(res.data._id)
      }
      setSaveMessage('✓ Roadmap successfully saved to your MongoDB account!')
    } catch (err) {
      setSaveMessage(`Error saving: ${err.message}`)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <span className="badge badge-cyan">3D Career Canvas</span>
            <span className="badge badge-verified">Karachi Milestones</span>
          </div>
          <h1 style={{ fontSize: '2.2rem' }}>Interactive Career Pathway Roadmap</h1>
          <p style={{ maxWidth: '640px', fontSize: '0.95rem' }}>
            Explore and customize a multi-year trajectory from your current educational stage into industry entry.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          <button
            type="button"
            className={`btn btn-sm ${activeTab === '3d' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('3d')}
          >
            3D Canvas View
          </button>
          <button
            type="button"
            className={`btn btn-sm ${activeTab === 'list' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setActiveTab('list')}
          >
            Structured List View
          </button>
          <button
            type="button"
            className="btn btn-amber btn-sm"
            onClick={handleSaveRoadmap}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Roadmap'}
          </button>
        </div>
      </div>

      {saveMessage && (
        <div
          style={{
            padding: '10px 16px',
            borderRadius: 'var(--radius-md)',
            background: saveMessage.startsWith('✓') ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)',
            border: `1px solid ${saveMessage.startsWith('✓') ? '#10B981' : '#EF4444'}`,
            color: saveMessage.startsWith('✓') ? '#34D399' : '#F87171',
            fontSize: '0.88rem',
          }}
        >
          {saveMessage}
        </div>
      )}

      {/* Aggregate Indicators */}
      <div className="grid-cols-3" style={{ gap: '16px' }}>
        <div className="card" style={{ padding: '16px 20px' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Estimated Trajectory
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--cyan)', marginTop: '4px' }}>
            ~{Math.round(totalMonths / 12 * 10) / 10} Years ({totalMonths} Mos)
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-dim)', marginTop: '2px' }}>
            Derived from milestone requirements
          </div>
        </div>

        <div className="card" style={{ padding: '16px 20px' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Estimated Investment
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#C59B27', marginTop: '4px' }}>
            PKR {totalBudget.toLocaleString()}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-dim)', marginTop: '2px' }}>
            Tuition, entrance tests, and course materials
          </div>
        </div>

        <div className="card" style={{ padding: '16px 20px' }}>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Milestones Completed
          </div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#10B981', marginTop: '4px' }}>
            {completedCount} / {milestones.length}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--text-dim)', marginTop: '2px' }}>
            {Math.round((completedCount / milestones.length) * 100)}% pathway completion
          </div>
        </div>
      </div>

      {/* Main View: 3D Canvas or List View */}
      {activeTab === '3d' ? (
        <CareerCanvas3D
          milestones={milestones}
          selectedNode={selectedNode}
          onSelectNode={setSelectedNode}
        />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {milestones.map((m, idx) => (
            <div
              key={m._id || m.id || idx}
              className={`card ${selectedNode?.title === m.title ? 'card-glow' : ''}`}
              style={{ cursor: 'pointer', padding: '20px 24px' }}
              onClick={() => setSelectedNode(m)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <span className="badge badge-cyan">STAGE {idx + 1}</span>
                <span
                  style={{
                    fontSize: '0.8rem',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    color: m.status === 'done' ? '#10B981' : m.status === 'in_progress' ? '#0284C7' : 'var(--text-dim)',
                  }}
                >
                  {m.status?.replace('_', ' ')}
                </span>
              </div>
              <h3 style={{ fontSize: '1.2rem', marginBottom: '6px' }}>{m.title}</h3>
              <p style={{ fontSize: '0.9rem' }}>{m.description}</p>
            </div>
          ))}
        </div>
      )}

      {/* Selected Node Detail & Editor Drawer */}
      {selectedNode && (
        <div className="card" style={{ padding: '28px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px', marginBottom: '16px' }}>
            <div>
              <span className="badge badge-cyan" style={{ marginBottom: '6px' }}>Milestone Inspector</span>
              <h2>{selectedNode.title}</h2>
            </div>

            <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Status:</span>
              <select
                className="form-select"
                style={{ width: 'auto', padding: '6px 12px', fontSize: '0.85rem' }}
                value={selectedNode.status || 'planned'}
                onChange={(e) => handleUpdateStatus(selectedNode._id || selectedNode.id, e.target.value)}
              >
                <option value="planned">Planned</option>
                <option value="in_progress">In Progress</option>
                <option value="done">Completed</option>
                <option value="skipped">Skipped</option>
              </select>
            </div>
          </div>

          <p style={{ fontSize: '0.95rem', marginBottom: '20px', lineHeight: '1.6' }}>
            {selectedNode.description}
          </p>

          <div className="grid-cols-2" style={{ gap: '20px', marginTop: '16px' }}>
            <div style={{ background: 'rgba(11, 19, 43, 0.6)', padding: '16px', borderRadius: 'var(--radius-md)' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#38BDF8', marginBottom: '8px' }}>
                Prerequisites & Qualifications
              </div>
              <ul style={{ listStyle: 'none', fontSize: '0.85rem', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                {selectedNode.prerequisites?.map((p, idx) => (
                  <li key={idx} style={{ color: 'var(--text-muted)' }}>• {p}</li>
                )) || <li style={{ color: 'var(--text-dim)' }}>Standard secondary progression</li>}
              </ul>
            </div>

            <div style={{ background: 'rgba(11, 19, 43, 0.6)', padding: '16px', borderRadius: 'var(--radius-md)' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#C59B27', marginBottom: '8px' }}>
                Core Skills Gained
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                {selectedNode.skills?.map((s, idx) => (
                  <span
                    key={idx}
                    style={{
                      fontSize: '0.78rem',
                      padding: '4px 8px',
                      borderRadius: '4px',
                      background: 'rgba(255,255,255,0.06)',
                      color: 'var(--text-main)',
                    }}
                  >
                    {s}
                  </span>
                )) || <span style={{ color: 'var(--text-dim)' }}>General academic literacy</span>}
              </div>
            </div>
          </div>

          {selectedNode.tradeoffs && (
            <div style={{ marginTop: '18px', padding: '12px 16px', background: 'rgba(197, 155, 39, 0.1)', border: '1px solid rgba(197, 155, 39, 0.25)', borderRadius: 'var(--radius-md)', fontSize: '0.85rem' }}>
              <strong style={{ color: '#FCD34D' }}>Decision Point & Trade-offs:</strong> {selectedNode.tradeoffs}
            </div>
          )}
        </div>
      )}

      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
    </div>
  )
}
