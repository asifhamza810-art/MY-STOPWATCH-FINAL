import { useEffect, useState } from 'react'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import AuthModal from '../components/ui/AuthModal'

export default function ArtifactVaultPage() {
  const { user } = useAuth()
  const [artifacts, setArtifacts] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [authModalOpen, setAuthModalOpen] = useState(false)

  // New artifact form state
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('project')
  const [projectUrl, setProjectUrl] = useState('')
  const [selectedFile, setSelectedFile] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  const loadArtifacts = async () => {
    if (!user) {
      setLoading(false)
      return
    }
    try {
      const res = await api('/artifacts', { auth: true })
      setArtifacts(res.data || [])
    } catch (err) {
      console.error('Failed to load artifacts:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadArtifacts()
  }, [user])

  const handleCreate = async (e) => {
    e.preventDefault()
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    setSubmitting(true)
    try {
      const formData = new FormData()
      formData.append('title', title)
      formData.append('description', description)
      formData.append('category', category)
      if (projectUrl) formData.append('projectUrl', projectUrl)
      if (selectedFile) formData.append('file', selectedFile)

      await api('/artifacts', {
        method: 'POST',
        auth: true,
        formData,
      })

      setShowAddModal(false)
      setTitle('')
      setDescription('')
      setProjectUrl('')
      setSelectedFile(null)
      await loadArtifacts()
    } catch (err) {
      alert(`Upload error: ${err.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to remove this artifact?')) return
    try {
      await api(`/artifacts/${id}`, { method: 'DELETE', auth: true })
      await loadArtifacts()
    } catch (err) {
      alert(`Delete error: ${err.message}`)
    }
  }

  if (!user) {
    return (
      <div style={{ maxWidth: '640px', margin: '60px auto', textAlign: 'center' }}>
        <div className="card" style={{ padding: '40px' }}>
          <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🔐</div>
          <h2>Student Artifact Vault</h2>
          <p style={{ margin: '12px 0 24px' }}>
            A secure repository for student-owned evidence: GitHub projects, research papers, competition certificates, and course outputs.
          </p>
          <button type="button" className="btn btn-primary" onClick={() => setAuthModalOpen(true)}>
            Sign In to Access Vault →
          </button>
        </div>
        {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
            <span className="badge badge-cyan">Evidence-Backed</span>
            <span className="badge badge-verified">Private & Shareable</span>
          </div>
          <h1>Student Artifact Vault</h1>
          <p style={{ maxWidth: '640px', fontSize: '0.95rem' }}>
            Record genuine evidence of your work. Link your GitHub repositories or upload certificates to prove competencies without manufactured credentials.
          </p>
        </div>

        <button type="button" className="btn btn-primary" onClick={() => setShowAddModal(true)}>
          + Add New Evidence
        </button>
      </div>

      {loading ? (
        <div className="grid-cols-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="card" style={{ height: '200px' }}>
              <div className="skeleton" style={{ height: '24px', width: '50%', marginBottom: '12px' }} />
              <div className="skeleton" style={{ height: '60px', width: '100%' }} />
            </div>
          ))}
        </div>
      ) : artifacts.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📁</div>
          <h3 className="empty-title">Your Vault Is Currently Empty</h3>
          <p className="empty-text">
            Start by adding a GitHub repository, competition certificate from Procom or Sentec, or project documentation.
          </p>
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShowAddModal(true)}>
            Add First Artifact
          </button>
        </div>
      ) : (
        <div className="grid-cols-3">
          {artifacts.map((art) => (
            <div key={art._id} className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                  <span className="badge badge-cyan">{art.category}</span>
                  <span style={{ fontSize: '0.78rem', color: '#10B981' }}>
                    {art.verificationState?.replace('_', ' ')}
                  </span>
                </div>

                <h3 style={{ fontSize: '1.2rem', marginBottom: '8px', color: '#FFFFFF' }}>{art.title}</h3>
                <p style={{ fontSize: '0.88rem', marginBottom: '16px' }}>{art.description}</p>

                {art.projectUrl && (
                  <div style={{ marginBottom: '12px' }}>
                    <a
                      href={art.projectUrl}
                      target="_blank"
                      rel="noreferrer"
                      style={{ fontSize: '0.82rem', color: '#38BDF8', wordBreak: 'break-all' }}
                    >
                      🔗 {art.projectUrl}
                    </a>
                  </div>
                )}

                {art.originalFilename && (
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginBottom: '12px' }}>
                    📄 {art.originalFilename} ({(art.fileSize / 1024).toFixed(1)} KB)
                  </div>
                )}
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '16px' }}>
                <button
                  type="button"
                  className="btn btn-outline btn-sm"
                  style={{ color: '#EF4444', borderColor: 'rgba(239, 68, 68, 0.3)' }}
                  onClick={() => handleDelete(art._id)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Artifact Modal */}
      {showAddModal && (
        <div className="modal-backdrop" onClick={() => setShowAddModal(false)}>
          <div className="modal-panel" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="modal-close" onClick={() => setShowAddModal(false)}>
              ✕
            </button>

            <h3 style={{ marginBottom: '8px' }}>Add Evidence Artifact</h3>
            <p style={{ fontSize: '0.88rem', marginBottom: '20px' }}>
              Store metadata and repository links for projects, certificates, or research.
            </p>

            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label className="form-label">Title</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="e.g. MERN Stack E-Commerce Platform"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Category</label>
                <select
                  className="form-select"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  <option value="project">Project / Application</option>
                  <option value="certificate">Course / Bootcamp Certificate</option>
                  <option value="research">Research / Case Study</option>
                  <option value="competition">Competition / Hackathon Deliverable</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Project / GitHub URL (Optional)</label>
                <input
                  type="url"
                  className="form-input"
                  placeholder="https://github.com/username/project"
                  value={projectUrl}
                  onChange={(e) => setProjectUrl(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Supporting Document (PDF/PNG/JPG)</label>
                <input
                  type="file"
                  className="form-input"
                  onChange={(e) => setSelectedFile(e.target.files[0] || null)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Description & Context</label>
                <textarea
                  className="form-textarea"
                  rows={3}
                  placeholder="Summarize technologies used, problem solved, and key milestones achieved."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                style={{ width: '100%', marginTop: '10px' }}
                disabled={submitting}
              >
                {submitting ? 'Uploading...' : 'Save to Vault'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
