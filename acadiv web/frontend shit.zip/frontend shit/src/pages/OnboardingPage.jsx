import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'

export default function OnboardingPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [track, setTrack] = useState(null) // 'fast' | 'guided'

  // Fast track form state
  const [stage, setStage] = useState('HSC Pre-Engineering')
  const [stream, setStream] = useState('Computer Science & Engineering')
  const [targetField, setTargetField] = useState('software-engineer')
  const [budget, setBudget] = useState('flexible')
  const [city, setCity] = useState('Karachi')
  const [saving, setSaving] = useState(false)

  const handleFastTrackSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      if (user) {
        await api('/profile', {
          method: 'PATCH',
          auth: true,
          body: {
            educationStage: stage,
            educationStream: stream,
            academicPreferences: { budget, targetField },
            city,
          },
        })
      }
      navigate('/roadmap')
    } catch (err) {
      console.error('Fast track profile save failed:', err)
      navigate('/roadmap')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div style={{ maxWidth: '840px', margin: '0 auto', padding: '20px 0' }}>
      <div style={{ textAlign: 'center', marginBottom: '40px' }}>
        <span className="badge badge-cyan" style={{ marginBottom: '12px' }}>
          Dual-Path Onboarding
        </span>
        <h1>How Would You Like to Start?</h1>
        <p style={{ maxWidth: '560px', margin: '8px auto 0' }}>
          Select the onboarding flow that matches your current clarity. You can always change your preferences later.
        </p>
      </div>

      {!track ? (
        <div className="grid-cols-2" style={{ gap: '24px' }}>
          {/* Option A: Fast Track */}
          <div
            className="card"
            style={{
              padding: '36px 28px',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
            }}
            onClick={() => setTrack('fast')}
          >
            <div>
              <div style={{ fontSize: '2.5rem', marginBottom: '16px' }}>⚡</div>
              <span className="badge badge-cyan" style={{ marginBottom: '8px' }}>Direct Route</span>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '12px' }}>Fast Track Planning</h2>
              <p style={{ fontSize: '0.92rem', marginBottom: '24px' }}>
                Already know your current education stage and target career? Select your Pakistani qualification and jump straight into your personalized 3D roadmap.
              </p>
              <ul style={{ listStyle: 'none', fontSize: '0.88rem', color: 'var(--text-dim)', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <li>✓ Select HSC / ICS / A-Levels</li>
                <li>✓ Pick target discipline</li>
                <li>✓ Immediate interactive roadmap</li>
              </ul>
            </div>

            <button
              type="button"
              className="btn btn-primary"
              style={{ marginTop: '32px', width: '100%' }}
              onClick={() => setTrack('fast')}
            >
              Choose Fast Track →
            </button>
          </div>

          {/* Option B: Guided Assessment */}
          <div
            className="card"
            style={{
              padding: '36px 28px',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
            }}
            onClick={() => navigate('/assessment')}
          >
            <div>
              <div style={{ fontSize: '2.5rem', marginBottom: '16px' }}>🧭</div>
              <span className="badge badge-featured" style={{ marginBottom: '8px' }}>Adaptive Exploration</span>
              <h2 style={{ fontSize: '1.5rem', marginBottom: '12px' }}>Guided RIASEC Assessment</h2>
              <p style={{ fontSize: '0.92rem', marginBottom: '24px' }}>
                Unsure about your career path? Complete our 15–20 question Pakistani scenario engine to generate an explainable Holland code and diagnostic profile.
              </p>
              <ul style={{ listStyle: 'none', fontSize: '0.88rem', color: 'var(--text-dim)', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                <li>✓ Realistic Karachi student scenarios</li>
                <li>✓ 6 RIASEC dimension scoring</li>
                <li>✓ Explainable matching traces</li>
              </ul>
            </div>

            <button
              type="button"
              className="btn btn-amber"
              style={{ marginTop: '32px', width: '100%' }}
              onClick={() => navigate('/assessment')}
            >
              Start Guided Assessment →
            </button>
          </div>
        </div>
      ) : (
        /* Fast Track Form */
        <div className="card" style={{ padding: '36px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
            <h3 style={{ fontSize: '1.4rem' }}>Fast Track Career Configuration</h3>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={() => setTrack(null)}
            >
              ← Back to Choice
            </button>
          </div>

          <form onSubmit={handleFastTrackSubmit}>
            <div className="form-group">
              <label className="form-label">Current Education Stage</label>
              <select
                className="form-select"
                value={stage}
                onChange={(e) => setStage(e.target.value)}
              >
                <option value="Matriculation Science">Matriculation (Science)</option>
                <option value="HSC Pre-Engineering">Intermediate / HSC Pre-Engineering</option>
                <option value="HSC Pre-Medical">Intermediate / HSC Pre-Medical</option>
                <option value="HSC ICS">Intermediate / ICS (Math, Physics, CS)</option>
                <option value="HSC General Science">Intermediate / General Science</option>
                <option value="HSC Commerce">Intermediate / Commerce</option>
                <option value="DAE Technical">DAE (Diploma of Associate Engineering)</option>
                <option value="O-Level">O-Level (Cambridge)</option>
                <option value="A-Level">A-Level (Cambridge)</option>
                <option value="Undergraduate Current">Current University Undergraduate</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Target Career Direction</label>
              <select
                className="form-select"
                value={targetField}
                onChange={(e) => setTargetField(e.target.value)}
              >
                <option value="software-engineer">Software Engineer / Web Developer</option>
                <option value="data-analyst">Data Analyst / Business Intelligence</option>
                <option value="ux-designer">Product / UX/UI Designer</option>
                <option value="civil-engineer">Civil & Structural Engineer</option>
                <option value="digital-marketer">Digital Marketer & Growth Strategist</option>
                <option value="accountant">Chartered Accountant / Finance</option>
                <option value="nursing-allied-health">Allied Healthcare / Nursing</option>
              </select>
            </div>

            <div className="grid-cols-2">
              <div className="form-group">
                <label className="form-label">City Focus</label>
                <input
                  type="text"
                  className="form-input"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Karachi"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Semester Budget Preference</label>
                <select
                  className="form-select"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                >
                  <option value="subsidized">Subsidized Merit / Public (e.g. NED, KU: Rs 30k–60k)</option>
                  <option value="moderate">Moderate Private / Semi-Govt (Rs 80k–150k)</option>
                  <option value="flexible">Flexible / Private Tier-1 (e.g. FAST, IBA: Rs 180k+)</option>
                  <option value="bootcamp">Free / Subsidized Skill Bootcamps (SMIT, Jawan)</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="btn btn-primary btn-lg"
              style={{ width: '100%', marginTop: '16px' }}
              disabled={saving}
            >
              {saving ? 'Saving Preferences...' : 'Launch Interactive Roadmap →'}
            </button>
          </form>
        </div>
      )}
    </div>
  )
}

