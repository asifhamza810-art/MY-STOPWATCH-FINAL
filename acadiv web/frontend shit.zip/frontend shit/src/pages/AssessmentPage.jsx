import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'
import AuthModal from '../components/ui/AuthModal'

export default function AssessmentPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [sessionId, setSessionId] = useState(null)
  const [currentQuestion, setCurrentQuestion] = useState(null)
  const [progress, setProgress] = useState(0)
  const [answeredCount, setAnsweredCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [showAuthModal, setShowAuthModal] = useState(false)

  // Local fallback questions for guest mode if not logged in
  const [guestAnswers, setGuestAnswers] = useState([])

  useEffect(() => {
    async function initAssessment() {
      setLoading(true)
      setError(null)
      if (user) {
        try {
          const res = await api('/assessment/start', { method: 'POST', auth: true })
          setSessionId(res.data.sessionId)
          setCurrentQuestion(res.data.nextQuestion)
          setAnsweredCount(res.data.answered || 0)
          setProgress(Math.min(100, Math.round(((res.data.answered || 0) / 15) * 100)))
        } catch (err) {
          console.error('Failed to start assessment session:', err)
          setError(err.message || 'Failed to initialize assessment engine.')
        } finally {
          setLoading(false)
        }
      } else {
        // Guest mode: fetch question catalog or load starting question
        setLoading(false)
      }
    }
    initAssessment()
  }, [user])

  const handleSelectOption = async (optionKey) => {
    if (!currentQuestion) return
    setSubmitting(true)
    setError(null)

    if (user && sessionId) {
      try {
        const res = await api('/assessment/answer', {
          method: 'POST',
          auth: true,
          body: {
            sessionId,
            questionId: currentQuestion.id,
            optionKey,
          },
        })

        if (res.data.status === 'completed' || res.data.result) {
          navigate('/profile/match')
          return
        }

        setCurrentQuestion(res.data.nextQuestion)
        const answered = (res.data.progress?.answered) || answeredCount + 1
        setAnsweredCount(answered)
        setProgress(Math.min(100, Math.round((answered / 15) * 100)))
      } catch (err) {
        setError(err.message || 'Failed to submit response.')
      } finally {
        setSubmitting(false)
      }
    }
  }

  if (!user) {
    return (
      <div style={{ maxWidth: '680px', margin: '40px auto', textAlign: 'center' }}>
        <div className="card" style={{ padding: '48px 32px' }}>
          <div style={{ fontSize: '3rem', marginBottom: '16px' }}>🧭</div>
          <span className="badge badge-cyan" style={{ marginBottom: '12px' }}>Student Session Required</span>
          <h2 style={{ marginBottom: '12px' }}>Save Your RIASEC Diagnostic Profile</h2>
          <p style={{ maxWidth: '500px', margin: '0 auto 28px', fontSize: '0.95rem' }}>
            To calculate your normalized Holland code, trace explainable matches, and persist your 3D roadmap,
            please sign in with your student account.
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: '14px' }}>
            <button
              type="button"
              className="btn btn-primary btn-lg"
              onClick={() => setShowAuthModal(true)}
            >
              Sign In / Register to Begin →
            </button>
          </div>
        </div>
        {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
      </div>
    )
  }

  if (loading) {
    return (
      <div style={{ maxWidth: '720px', margin: '60px auto', textAlign: 'center' }}>
        <div className="skeleton" style={{ height: '24px', width: '200px', margin: '0 auto 16px' }} />
        <div className="skeleton" style={{ height: '48px', width: '80%', margin: '0 auto 24px' }} />
        <div className="skeleton" style={{ height: '140px', width: '100%', borderRadius: 'var(--radius-lg)' }} />
      </div>
    )
  }

  if (!currentQuestion) {
    return (
      <div style={{ maxWidth: '680px', margin: '60px auto', textAlign: 'center' }}>
        <div className="card" style={{ padding: '40px' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '12px' }}>🎉</div>
          <h2>Assessment Complete!</h2>
          <p style={{ margin: '12px 0 24px' }}>
            Your RIASEC answers have been recorded and scored against the versioned scoring engine.
          </p>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => navigate('/profile/match')}
          >
            View Diagnostic Match Profile →
          </button>
        </div>
      </div>
    )
  }

  return (
    <div style={{ maxWidth: '780px', margin: '0 auto', padding: '20px 0' }}>
      {/* Header & Progress */}
      <div style={{ marginBottom: '32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
          <span className="badge badge-cyan">RIASEC Version: riasec-pk-v1</span>
          <span style={{ fontSize: '0.88rem', fontWeight: 600, color: 'var(--text-muted)' }}>
            Question {answeredCount + 1} of 15–20
          </span>
        </div>

        {/* Progress Bar */}
        <div
          style={{
            width: '100%',
            height: '8px',
            borderRadius: 'var(--radius-full)',
            background: 'rgba(255, 255, 255, 0.08)',
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              width: `${Math.max(5, progress)}%`,
              height: '100%',
              background: 'linear-gradient(90deg, #0284C7, #38BDF8)',
              transition: 'width 0.3s ease',
            }}
          />
        </div>
      </div>

      {error && (
        <div
          style={{
            padding: '12px 16px',
            borderRadius: 'var(--radius-md)',
            background: 'rgba(239, 68, 68, 0.15)',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            color: '#F87171',
            marginBottom: '20px',
            fontSize: '0.9rem',
          }}
        >
          {error}
        </div>
      )}

      {/* Question Card */}
      <div className="card card-glow" style={{ padding: '36px 32px', marginBottom: '24px' }}>
        {currentQuestion.scenarioContext && (
          <div
            style={{
              fontSize: '0.8rem',
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
              fontWeight: 700,
              color: '#38BDF8',
              marginBottom: '10px',
            }}
          >
            📍 Scenario: {currentQuestion.scenarioContext}
          </div>
        )}

        <h2 style={{ fontSize: '1.45rem', lineHeight: '1.4', marginBottom: '28px' }}>
          {currentQuestion.text}
        </h2>

        {/* Options */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
          {currentQuestion.options?.map((opt) => (
            <button
              key={opt.key}
              type="button"
              disabled={submitting}
              onClick={() => handleSelectOption(opt.key)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '16px',
                padding: '18px 20px',
                borderRadius: 'var(--radius-md)',
                background: 'rgba(11, 19, 43, 0.7)',
                border: '1px solid var(--border)',
                color: 'var(--text-main)',
                fontSize: '0.98rem',
                textAlign: 'left',
                cursor: submitting ? 'wait' : 'pointer',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                if (!submitting) {
                  e.currentTarget.style.borderColor = 'var(--cyan)'
                  e.currentTarget.style.background = 'rgba(2, 132, 199, 0.12)'
                  e.currentTarget.style.transform = 'translateX(4px)'
                }
              }}
              onMouseLeave={(e) => {
                if (!submitting) {
                  e.currentTarget.style.borderColor = 'var(--border)'
                  e.currentTarget.style.background = 'rgba(11, 19, 43, 0.7)'
                  e.currentTarget.style.transform = 'translateX(0)'
                }
              }}
            >
              <div
                style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  background: 'rgba(255, 255, 255, 0.08)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 700,
                  fontSize: '0.85rem',
                  color: 'var(--cyan)',
                  flexShrink: 0,
                }}
              >
                {opt.key.toUpperCase()}
              </div>
              <div style={{ flex: 1, lineHeight: '1.4' }}>{opt.label}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Disclaimers & Transparency */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          padding: '12px 18px',
          background: 'rgba(28, 37, 65, 0.4)',
          borderRadius: 'var(--radius-md)',
          fontSize: '0.82rem',
          color: 'var(--text-dim)',
        }}
      >
        <span>ℹ️</span>
        <span>
          Acadiv RIASEC questions test inclinations through realistic Pakistani student moments. Results provide exploratory guidance, not a medical or clinical diagnosis.
        </span>
      </div>
    </div>
  )
}
