import { useEffect, useState } from 'react'
import { api } from '../lib/api'

export default function InstitutionsPage() {
  const [institutions, setInstitutions] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [selectedInst, setSelectedInst] = useState(null)
  const [detailData, setDetailData] = useState(null)
  const [detailLoading, setDetailLoading] = useState(false)

  useEffect(() => {
    async function loadInstitutions() {
      setLoading(true)
      try {
        let path = '/institutions?limit=50'
        if (search) path += `&q=${encodeURIComponent(search)}`
        if (selectedCategory) path += `&category=${encodeURIComponent(selectedCategory)}`
        const res = await api(path)
        setInstitutions(res.data || [])
      } catch (err) {
        console.error('Failed to load institutions:', err)
      } finally {
        setLoading(false)
      }
    }
    const timer = setTimeout(loadInstitutions, 250)
    return () => clearTimeout(timer)
  }, [search, selectedCategory])

  const handleOpenDetail = async (inst) => {
    setSelectedInst(inst)
    setDetailLoading(true)
    try {
      const res = await api(`/institutions/${inst.slug || inst._id}`)
      setDetailData(res.data)
    } catch (err) {
      console.error('Failed to load institution details:', err)
    } finally {
      setDetailLoading(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <span className="badge badge-cyan">Karachi Directory</span>
          <span className="badge badge-verified">HEC / PEC Verified</span>
        </div>
        <h1>Karachi Institution Explorer</h1>
        <p style={{ maxWidth: '640px', fontSize: '0.95rem' }}>
          Real, evidence-backed university profiles, accredited degree programmes, published semester fees, and official admission test requirements.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="filter-bar">
        <div className="search-box">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search NED, IBA, FAST, Computer Science..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          className="form-select"
          style={{ width: 'auto', minWidth: '160px' }}
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value="">All Categories</option>
          <option value="university">Universities</option>
          <option value="college">Colleges</option>
        </select>
      </div>

      {/* Loading Skeletons */}
      {loading ? (
        <div className="grid-cols-3">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="card" style={{ height: '240px' }}>
              <div className="skeleton" style={{ height: '20px', width: '60%', marginBottom: '16px' }} />
              <div className="skeleton" style={{ height: '80px', width: '100%', marginBottom: '16px' }} />
              <div className="skeleton" style={{ height: '36px', width: '100%' }} />
            </div>
          ))}
        </div>
      ) : institutions.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🏛️</div>
          <h3 className="empty-title">No Institutions Found</h3>
          <p className="empty-text">Try broadening your search term or clearing filters.</p>
        </div>
      ) : (
        <div className="grid-cols-3">
          {institutions.map((inst) => (
            <div key={inst._id} className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                  <span className="badge badge-verified">
                    {inst.ownershipType} {inst.category}
                  </span>
                  <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                    {inst.city}
                  </span>
                </div>

                <h3 style={{ fontSize: '1.25rem', marginBottom: '8px', lineHeight: '1.3' }}>
                  {inst.name}
                </h3>

                <p style={{ fontSize: '0.88rem', marginBottom: '16px', lineHeight: '1.5' }}>
                  {inst.description}
                </p>

                {inst.recognitionNote && (
                  <div style={{ fontSize: '0.78rem', color: '#10B981', marginBottom: '16px' }}>
                    ✓ {inst.recognitionNote}
                  </div>
                )}
              </div>

              <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  style={{ flex: 1 }}
                  onClick={() => handleOpenDetail(inst)}
                >
                  View Programmes & Fees
                </button>
                {inst.admissionsWebsite && (
                  <a
                    href={inst.admissionsWebsite}
                    target="_blank"
                    rel="noreferrer"
                    className="btn btn-outline btn-sm"
                    title="Official Admissions Portal"
                  >
                    Portal ↗
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Institution Detail Modal */}
      {selectedInst && (
        <div className="modal-backdrop" onClick={() => setSelectedInst(null)}>
          <div className="modal-panel" style={{ maxWidth: '720px', maxHeight: '85vh', overflowY: 'auto' }} onClick={(e) => e.stopPropagation()}>
            <button type="button" className="modal-close" onClick={() => setSelectedInst(null)}>
              ✕
            </button>

            <span className="badge badge-cyan" style={{ marginBottom: '8px' }}>
              {selectedInst.ownershipType} • {selectedInst.city}
            </span>
            <h2 style={{ fontSize: '1.6rem', marginBottom: '8px' }}>{selectedInst.name}</h2>
            <p style={{ fontSize: '0.92rem', marginBottom: '20px' }}>{selectedInst.description}</p>

            {detailLoading ? (
              <div className="skeleton" style={{ height: '160px', width: '100%', borderRadius: 'var(--radius-md)' }} />
            ) : detailData ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                {/* Campuses */}
                {detailData.campuses?.length > 0 && (
                  <div>
                    <h4 style={{ color: '#FFFFFF', marginBottom: '10px' }}>Campuses</h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {detailData.campuses.map((c) => (
                        <div key={c._id} style={{ padding: '10px 14px', background: 'rgba(11, 19, 43, 0.6)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)', fontSize: '0.88rem' }}>
                          <strong>{c.name}</strong> — {c.address || c.area}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Programmes */}
                {detailData.programmes?.length > 0 && (
                  <div>
                    <h4 style={{ color: '#FFFFFF', marginBottom: '10px' }}>Accredited Programmes</h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      {detailData.programmes.map((p) => (
                        <div key={p._id} style={{ padding: '14px', background: 'rgba(11, 19, 43, 0.7)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                            <strong style={{ color: '#38BDF8', fontSize: '0.98rem' }}>{p.title}</strong>
                            <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>{p.duration}</span>
                          </div>
                          <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '4px' }}>
                            Eligibility: {p.educationStageEligibility?.join(', ')} ({p.publishedMinimumMarks})
                          </div>
                          {p.requiredTests?.length > 0 && (
                            <div style={{ fontSize: '0.82rem', color: '#FCD34D' }}>
                              Entrance Test: {p.requiredTests.join(', ')}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Published Fees */}
                {detailData.fees?.length > 0 && (
                  <div>
                    <h4 style={{ color: '#FFFFFF', marginBottom: '10px' }}>Verified Fee Structure</h4>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {detailData.fees.map((f) => (
                        <div key={f._id} style={{ padding: '12px 14px', background: 'rgba(197, 155, 39, 0.08)', borderRadius: 'var(--radius-md)', border: '1px solid rgba(197, 155, 39, 0.3)', fontSize: '0.88rem' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, color: '#FCD34D' }}>
                            <span>Academic Year {f.academicYear}</span>
                            <span>PKR {f.amount?.toLocaleString()} {f.paymentFrequency}</span>
                          </div>
                          {f.additionalChargesNote && (
                            <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginTop: '4px' }}>
                              {f.additionalChargesNote}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div style={{ display: 'flex', gap: '12px', marginTop: '8px' }}>
                  {selectedInst.officialWebsite && (
                    <a href={selectedInst.officialWebsite} target="_blank" rel="noreferrer" className="btn btn-primary btn-sm" style={{ flex: 1 }}>
                      Visit Official University Website ↗
                    </a>
                  )}
                  {selectedInst.admissionsWebsite && (
                    <a href={selectedInst.admissionsWebsite} target="_blank" rel="noreferrer" className="btn btn-secondary btn-sm" style={{ flex: 1 }}>
                      Admissions Portal ↗
                    </a>
                  )}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  )
}

