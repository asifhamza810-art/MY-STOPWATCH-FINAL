import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api'
import { useAuth } from '../context/AuthContext'
import AuthModal from '../components/ui/AuthModal'

export default function SkillGapPage() {
  const { user } = useAuth()
  const [skills, setSkills] = useState([])
  const [studentSkills, setStudentSkills] = useState([])
  const [gaps, setGaps] = useState([])
  const [loading, setLoading] = useState(true)
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [updatingId, setUpdatingId] = useState(null)

  useEffect(() => {
    async function loadData() {
      try {
        const sRes = await api('/skills')
        setSkills(sRes.data || [])

        if (user) {
          const gapRes = await api('/skill-gap', { auth: true })
          setStudentSkills(gapRes.data?.studentSkills || [])
          setGaps(gapRes.data?.assessment?.gaps || [])
        }
      } catch (err) {
        console.error('Failed to load skill gap data:', err)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [user])

  const handleUpdateLevel = async (skillId, declaredLevel) => {
    if (!user) {
      setAuthModalOpen(true)
      return
    }
    setUpdatingId(skillId)
    try {
      await api('/student-skills', {
        method: 'PUT',
        auth: true,
        body: { skillId, declaredLevel },
      })
      // Refresh gap data
      const gapRes = await api('/skill-gap', { auth: true })
      setStudentSkills(gapRes.data?.studentSkills || [])
      setGaps(gapRes.data?.assessment?.gaps || [])
    } catch (err) {
      console.error('Failed to update student skill:', err)
    } finally {
      setUpdatingId(null)
    }
  }

  const getDeclaredLevel = (skillId) => {
    const found = studentSkills.find((s) => s.skillId?._id === skillId || s.skillId === skillId)
    return found ? found.declaredLevel : 'none'
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <span className="badge badge-cyan">Competency Diagnostic</span>
          <span className="badge badge-verified">P@SHA / HEC Benchmark</span>
        </div>
        <h1>Skill-Gap Analysis</h1>
        <p style={{ maxWidth: '640px', fontSize: '0.95rem' }}>
          Compare your self-declared competencies against baseline expectations for Pakistani software and analytics entry roles.
        </p>
      </div>

      {!user && (
        <div className="card card-glow" style={{ padding: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
          <div>
            <h4 style={{ color: '#FFFFFF' }}>Sign In to Track Your Skills</h4>
            <p style={{ fontSize: '0.88rem' }}>Save declared competencies and connect them directly to your Artifact Vault evidence.</p>
          </div>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setAuthModalOpen(true)}>
            Sign In Now
          </button>
        </div>
      )}

      {/* Prioritized Actionable Gaps */}
      {gaps.length > 0 && (
        <div>
          <h3 style={{ marginBottom: '16px' }}>Prioritized Skill Recommendations</h3>
          <div className="grid-cols-2" style={{ gap: '16px' }}>
            {gaps.slice(0, 6).map((gap, idx) => (
              <div key={idx} className="card" style={{ padding: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <h4 style={{ color: '#FFFFFF' }}>{gap.skillName}</h4>
                  <span className={`badge ${gap.priority === 'high' ? 'badge-provisional' : 'badge-cyan'}`}>
                    {gap.priority} priority
                  </span>
                </div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-dim)', marginBottom: '12px' }}>
                  Current: <strong style={{ color: 'var(--text-main)' }}>{gap.currentLevel}</strong> • Target: <strong style={{ color: '#10B981' }}>{gap.targetLevel}</strong>
                </div>
                <p style={{ fontSize: '0.85rem', marginBottom: '16px' }}>{gap.reason}</p>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  <Link to="/skills" className="btn btn-secondary btn-sm">
                    Find Course under Skill Firms →
                  </Link>
                  <Link to="/vault" className="btn btn-outline btn-sm">
                    Add Vault Evidence
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Editable Skills Catalog */}
      <div className="card">
        <h3 style={{ marginBottom: '16px' }}>Your Declared Competencies</h3>
        <p style={{ fontSize: '0.88rem', marginBottom: '20px' }}>
          Select your working level for each skill. Claims can be validated by uploading project repositories or certificates to your Artifact Vault.
        </p>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {skills.map((skill) => {
            const current = getDeclaredLevel(skill._id)
            return (
              <div
                key={skill._id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '12px 16px',
                  background: 'rgba(11, 19, 43, 0.6)',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid var(--border)',
                  flexWrap: 'wrap',
                  gap: '12px',
                }}
              >
                <div>
                  <div style={{ fontWeight: 600, color: '#FFFFFF' }}>{skill.name}</div>
                  <div style={{ fontSize: '0.78rem', color: 'var(--text-dim)', textTransform: 'capitalize' }}>
                    Category: {skill.category}
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <select
                    className="form-select"
                    style={{ width: 'auto', padding: '6px 12px', fontSize: '0.82rem' }}
                    value={current}
                    disabled={updatingId === skill._id}
                    onChange={(e) => handleUpdateLevel(skill._id, e.target.value)}
                  >
                    <option value="none">No Experience (None)</option>
                    <option value="exploring">Exploring / Beginner</option>
                    <option value="working">Working Competency</option>
                    <option value="advanced">Advanced / Production</option>
                  </select>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {authModalOpen && <AuthModal onClose={() => setAuthModalOpen(false)} />}
    </div>
  )
}
