import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../lib/api'

export default function DiagnosticMatchPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [matchData, setMatchData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [ikigaiNotes, setIkigaiNotes] = useState({ love: '', goodAt: '', worldNeeds: '', paidFor: '' })
  const [ikigaiSaved, setIkigaiSaved] = useState(false)

  useEffect(() => {
    async function loadMatch() {
      if (!user) {
        setLoading(false)
        return
      }
      try {
        const res = await api('/profile/match', { auth: true })
        setMatchData(res.data?.result || null)
      } catch (err) {
        console.error('Failed to load profile match:', err)
      } finally {
        setLoading(false)
      }
    }
    loadMatch()
  }, [user])

  if (!user) {
    return (
      <div style={{ maxWidth: '640px', margin: '60px auto', textAlign: 'center' }}>
        <div className="card" style={{ padding: '40px' }}>
          <h2>Diagnostic Profile</h2>
          <p style={{ margin: '16px 0 24px' }}>
            Please sign in to view your diagnostic match results and Holland code profile.
          </p>
          <Link to="/onboarding" className="btn btn-primary">
            Sign In or Start Assessment →
          </Link>
        </div>
      </div>
    )
  }

  if (loading) {
    return (
      <div style={{ maxWidth: '840px', margin: '40px auto' }}>
        <div className="skeleton" style={{ height: '32px', width: '300px', marginBottom: '24px' }} />
        <div className="grid-cols-2" style={{ gap: '20px' }}>
          <div className="skeleton" style={{ height: '240px' }} />
          <div className="skeleton" style={{ height: '240px' }} />
        </div>
      </div>
    )
  }

  if (!matchData) {
    return (
      <div style={{ maxWidth: '680px', margin: '40px auto', textAlign: 'center' }}>
        <div className="empty-state">
          <div className="empty-icon">📊</div>
          <h2 className="empty-title">No Completed Assessment Yet</h2>
          <p className="empty-text">
            You haven't completed the 15–20 question RIASEC assessment yet. Take the adaptive assessment to generate your explainable profile.
          </p>
          <Link to="/assessment" className="btn btn-primary">
            Begin RIASEC Assessment →
          </Link>
        </div>
      </div>
    )
  }

  const dimensions = [
    { key: 'R', label: 'Realistic', color: '#0284C7', desc: 'Practical, tools, physical systems' },
    { key: 'I', label: 'Investigative', color: '#38BDF8', desc: 'Analytical, research, deep thinking' },
    { key: 'A', label: 'Artistic', color: '#A855F7', desc: 'Creative, expressive, UX design' },
    { key: 'S', label: 'Social', color: '#10B981', desc: 'Mentoring, community, healthcare' },
    { key: 'E', label: 'Enterprising', color: '#C59B27', desc: 'Leadership, ventures, persuasion' },
    { key: 'C', label: 'Conventional', color: '#64748B', desc: 'Organization, data, structured systems' },
  ]

  const scores = matchData.normalizedScores || {}

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '36px' }}>
      {/* Top Banner with Holland Code */}
      <div className="card card-glow" style={{ padding: '36px', display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '24px' }}>
        <div>
          <span className="badge badge-cyan" style={{ marginBottom: '8px' }}>
            Diagnostic RIASEC Profile
          </span>
          <h1 style={{ fontSize: '2.4rem', margin: '6px 0 12px' }}>
            Holland Code: <span style={{ color: '#38BDF8', letterSpacing: '0.08em' }}>{matchData.hollandCode}</span>
          </h1>
          <p style={{ maxWidth: '580px', fontSize: '0.95rem' }}>
            Your three dominant dimensions reflect your practical preferences across Karachi educational and career pathways.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
          <Link to="/roadmap" className="btn btn-primary">
            Build Career Roadmap →
          </Link>
          <Link to="/skill-gap" className="btn btn-outline">
            Skill-Gap Analysis
          </Link>
        </div>
      </div>

      {/* 6 Dimension Visualizations */}
      <div className="card">
        <h3 style={{ marginBottom: '20px' }}>Dimension Distribution (Normalized 0–100)</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {dimensions.map((d) => {
            const val = scores[d.key] || 0
            return (
              <div key={d.key}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '0.9rem' }}>
                  <div>
                    <strong>{d.key} — {d.label}</strong>{' '}
                    <span style={{ color: 'var(--text-dim)', fontSize: '0.82rem' }}>({d.desc})</span>
                  </div>
                  <div style={{ fontWeight: 700, color: d.color }}>{val}%</div>
                </div>
                <div style={{ width: '100%', height: '10px', borderRadius: 'var(--radius-full)', background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                  <div
                    style={{
                      width: `${val}%`,
                      height: '100%',
                      background: d.color,
                      borderRadius: 'var(--radius-full)',
                      transition: 'width 0.6s ease',
                    }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Recommended Career Directions */}
      <div>
        <h3 style={{ marginBottom: '16px' }}>Plausible Career Directions (Explainable Matches)</h3>
        <div className="grid-cols-2" style={{ gap: '20px' }}>
          {matchData.recommendedCareers?.length ? (
            matchData.recommendedCareers.map((c) => (
              <div key={c.careerId || c.title} className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                  <h4 style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>{c.title}</h4>
                  <span className="badge badge-verified">Aligned</span>
                </div>
                <p style={{ fontSize: '0.88rem', marginBottom: '14px' }}>{c.description}</p>
                <div style={{ fontSize: '0.82rem', color: '#38BDF8', background: 'rgba(2, 132, 199, 0.1)', padding: '8px 12px', borderRadius: 'var(--radius-sm)', marginBottom: '16px' }}>
                  <strong>Why matched:</strong> Aligns with your high {matchData.hollandCode?.slice(0, 2)} focus on analytical problem-solving and structured technical implementation.
                </div>
                <Link to="/roadmap" className="btn btn-secondary btn-sm" style={{ width: '100%' }}>
                  View Pathway on 3D Roadmap
                </Link>
              </div>
            ))
          ) : (
            <div className="card" style={{ gridColumn: 'span 2', textAlign: 'center', padding: '24px' }}>
              <p>Explore all available careers on the 3D Roadmap.</p>
              <Link to="/roadmap" className="btn btn-primary btn-sm" style={{ marginTop: '12px' }}>
                Open Roadmap
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Auditable Reason Trace */}
      <div className="card" style={{ background: 'rgba(11, 19, 43, 0.6)' }}>
        <h3 style={{ marginBottom: '14px' }}>Auditable Scoring Trace</h3>
        <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginBottom: '16px' }}>
          This trace is calculated from your actual recorded answers and versioned scoring rules (`riasec-pk-v1`).
        </p>
        <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          {matchData.reasonTrace?.map((item, idx) => (
            <li key={idx} style={{ padding: '6px 10px', background: 'rgba(255, 255, 255, 0.03)', borderRadius: '4px' }}>
              • {item}
            </li>
          ))}
        </ul>
      </div>

      {/* Optional Ikigai Reflection */}
      <div className="card">
        <h3 style={{ marginBottom: '8px' }}>Optional Ikigai-Inspired Reflection</h3>
        <p style={{ fontSize: '0.88rem', marginBottom: '20px' }}>
          Separate from RIASEC scores, capture what energizes you personally to refine your roadmap milestones.
        </p>

        <div className="grid-cols-2" style={{ gap: '16px' }}>
          <div className="form-group">
            <label className="form-label">What You Genuinely Enjoy</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Building interactive web tools, debugging"
              value={ikigaiNotes.love}
              onChange={(e) => setIkigaiNotes({ ...ikigaiNotes, love: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">What You Are Developing</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Advanced JavaScript, mathematical proofs"
              value={ikigaiNotes.goodAt}
              onChange={(e) => setIkigaiNotes({ ...ikigaiNotes, goodAt: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">What Karachi / Industry Needs</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Reliable software engineers, AI agents, cloud dev"
              value={ikigaiNotes.worldNeeds}
              onChange={(e) => setIkigaiNotes({ ...ikigaiNotes, worldNeeds: e.target.value })}
            />
          </div>

          <div className="form-group">
            <label className="form-label">What Is Economically Sustainable</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Tech freelancing, local software houses, remote US/EU"
              value={ikigaiNotes.paidFor}
              onChange={(e) => setIkigaiNotes({ ...ikigaiNotes, paidFor: e.target.value })}
            />
          </div>
        </div>

        <button
          type="button"
          className="btn btn-secondary btn-sm"
          onClick={() => setIkigaiSaved(true)}
        >
          {ikigaiSaved ? '✓ Saved to Local Notes' : 'Save Reflection'}
        </button>
      </div>
    </div>
  )
}

