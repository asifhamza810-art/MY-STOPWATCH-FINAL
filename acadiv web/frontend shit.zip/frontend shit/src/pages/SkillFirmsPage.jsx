import { useEffect, useState } from 'react'
import { api } from '../lib/api'

export default function SkillFirmsPage() {
  const [firms, setFirms] = useState([])
  const [courses, setCourses] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedDomain, setSelectedDomain] = useState('')
  const [search, setSearch] = useState('')
  const [selectedFirm, setSelectedFirm] = useState(null)
  const [firmCourses, setFirmCourses] = useState([])
  const [firmCoursesLoading, setFirmCoursesLoading] = useState(false)

  useEffect(() => {
    async function loadData() {
      setLoading(true)
      try {
        let path = '/skill-firms?limit=50'
        if (selectedDomain) path += `&domain=${encodeURIComponent(selectedDomain)}`
        if (search) path += `&q=${encodeURIComponent(search)}`

        const [fRes, cRes] = await Promise.all([
          api(path),
          api('/courses?limit=50'),
        ])
        setFirms(fRes.data || [])
        setCourses(cRes.data || [])
      } catch (err) {
        console.error('Failed to load skill firms:', err)
      } finally {
        setLoading(false)
      }
    }
    const timer = setTimeout(loadData, 250)
    return () => clearTimeout(timer)
  }, [selectedDomain, search])

  const handleOpenFirm = async (firm) => {
    setSelectedFirm(firm)
    setFirmCoursesLoading(true)
    try {
      const res = await api(`/skill-firms/${firm.slug || firm._id}`)
      setFirmCourses(res.data?.courses || [])
    } catch (err) {
      console.error('Failed to load firm courses:', err)
    } finally {
      setFirmCoursesLoading(false)
    }
  }

  // The database query in catalogController sorts by { isFeatured: -1, featuredPriority: 1, name: 1 }
  // So Jawan Pakistan is guaranteed to be firms[0] when featured!
  const featuredFirm = firms.find((f) => f.isFeatured)
  const otherFirms = firms.filter((f) => !f.isFeatured)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '40px' }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
          <span className="badge badge-featured">Editorial Spotlight</span>
          <span className="badge badge-verified">Karachi Providers</span>
        </div>
        <h1>Karachi Skill-Enhancing Bootcamps & Firms</h1>
        <p style={{ maxWidth: '680px', fontSize: '0.98rem' }}>
          Discover verified local tech bootcamps, hands-on software academies, and subsidized skills programmes.
          Every listed course contains verified fees, duration, and registration links.
        </p>
      </div>

      {/* Featured Hero Placement: Jawan Pakistan */}
      {featuredFirm && (
        <section
          className="card card-glow"
          style={{
            padding: '36px',
            background: 'linear-gradient(135deg, rgba(28, 37, 65, 0.85) 0%, rgba(10, 17, 40, 0.95) 100%)',
            border: '1px solid rgba(197, 155, 39, 0.4)',
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px', marginBottom: '16px' }}>
            <span className="badge badge-featured">
              ★ {featuredFirm.featuredLabel || 'Acadiv Featured Placement'}
            </span>
            <span style={{ fontSize: '0.85rem', color: '#FCD34D' }}>
              📍 {featuredFirm.campusArea || 'Gulistan-e-Johar, Karachi'}
            </span>
          </div>

          <h2 style={{ fontSize: '2rem', marginBottom: '12px' }}>{featuredFirm.name}</h2>
          <p style={{ fontSize: '1.02rem', maxWidth: '800px', marginBottom: '20px', lineHeight: '1.6' }}>
            {featuredFirm.description}
          </p>

          <div style={{ fontSize: '0.85rem', color: 'var(--text-dim)', marginBottom: '24px' }}>
            <strong>Campus Location:</strong> {featuredFirm.karachiLocation}
          </div>

          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginBottom: '28px' }}>
            {featuredFirm.skillDomains?.map((domain) => (
              <span
                key={domain}
                style={{
                  fontSize: '0.82rem',
                  padding: '4px 12px',
                  borderRadius: 'var(--radius-full)',
                  background: 'rgba(197, 155, 39, 0.15)',
                  border: '1px solid rgba(197, 155, 39, 0.3)',
                  color: '#FCD34D',
                }}
              >
                {domain}
              </span>
            ))}
          </div>

          <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
            <button
              type="button"
              className="btn btn-amber btn-lg"
              onClick={() => handleOpenFirm(featuredFirm)}
            >
              Explore Jawan Pakistan Courses ({courses.filter((c) => c.providerId?.name === featuredFirm.name || c.providerId?._id === featuredFirm._id).length || 2}) →
            </button>
            {featuredFirm.website && (
              <a
                href={featuredFirm.website}
                target="_blank"
                rel="noreferrer"
                className="btn btn-outline btn-lg"
              >
                Official Website ↗
              </a>
            )}
          </div>
        </section>
      )}

      {/* Filter Bar */}
      <div className="filter-bar">
        <div className="search-box">
          <span className="search-icon">🔍</span>
          <input
            type="text"
            placeholder="Search AI, Full Stack, Saylani, Flutter..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          className="form-select"
          style={{ width: 'auto', minWidth: '160px' }}
          value={selectedDomain}
          onChange={(e) => setSelectedDomain(e.target.value)}
        >
          <option value="">All Skill Domains</option>
          <option value="AI">AI & Agents</option>
          <option value="Web">Web Development</option>
          <option value="Flutter">Flutter & Mobile</option>
          <option value="Digital Marketing">Digital Marketing</option>
          <option value="Cloud">Cloud & DevOps</option>
        </select>
      </div>

      {/* Other Verified Training Providers */}
      <div>
        <h3 style={{ marginBottom: '20px' }}>All Verified Karachi Skill Providers</h3>
        {loading ? (
          <div className="grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card" style={{ height: '220px' }}>
                <div className="skeleton" style={{ height: '20px', width: '50%', marginBottom: '14px' }} />
                <div className="skeleton" style={{ height: '70px', width: '100%', marginBottom: '14px' }} />
                <div className="skeleton" style={{ height: '36px', width: '100%' }} />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid-cols-3">
            {firms.map((firm) => (
              <div
                key={firm._id}
                className={`card ${firm.isFeatured ? 'card-glow' : ''}`}
                style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}
              >
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                    <span className={`badge ${firm.isFeatured ? 'badge-featured' : 'badge-cyan'}`}>
                      {firm.isFeatured ? 'Featured Placement' : 'Verified Provider'}
                    </span>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                      {firm.campusArea}
                    </span>
                  </div>

                  <h3 style={{ fontSize: '1.25rem', marginBottom: '8px' }}>{firm.name}</h3>
                  <p style={{ fontSize: '0.88rem', marginBottom: '16px' }}>{firm.description}</p>

                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '16px' }}>
                    {firm.skillDomains?.slice(0, 3).map((d) => (
                      <span
                        key={d}
                        style={{
                          fontSize: '0.75rem',
                          padding: '2px 8px',
                          borderRadius: '4px',
                          background: 'rgba(255,255,255,0.06)',
                          color: 'var(--text-muted)',
                        }}
                      >
                        {d}
                      </span>
                    ))}
                  </div>
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    style={{ flex: 1 }}
                    onClick={() => handleOpenFirm(firm)}
                  >
                    View Courses
                  </button>
                  {firm.website && (
                    <a
                      href={firm.website}
                      target="_blank"
                      rel="noreferrer"
                      className="btn btn-outline btn-sm"
                    >
                      Website ↗
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Courses Catalog Section */}
      <div>
        <h3 style={{ marginBottom: '20px' }}>Active Verified Tech Courses in Karachi</h3>
        <div className="grid-cols-2" style={{ gap: '20px' }}>
          {courses.map((course) => (
            <div key={course._id} className="card" style={{ padding: '24px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                <span className="badge badge-cyan">{course.level || 'all levels'}</span>
                <span style={{ fontSize: '0.82rem', color: '#10B981', fontWeight: 600 }}>
                  {course.deliveryMode?.toUpperCase()}
                </span>
              </div>

              <h4 style={{ fontSize: '1.25rem', color: '#FFFFFF', marginBottom: '6px' }}>
                {course.title}
              </h4>
              <div style={{ fontSize: '0.85rem', color: '#38BDF8', fontWeight: 600, marginBottom: '12px' }}>
                Provider: {course.providerId?.name || 'Verified Partner'}
              </div>

              <p style={{ fontSize: '0.88rem', marginBottom: '16px' }}>
                {course.description}
              </p>

              <div style={{ background: 'rgba(11, 19, 43, 0.6)', padding: '12px', borderRadius: 'var(--radius-md)', fontSize: '0.85rem', marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Duration:</span>
                  <strong>{course.duration}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Eligibility:</span>
                  <strong>{course.eligibility}</strong>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Published Fee:</span>
                  <strong style={{ color: '#FCD34D' }}>
                    {course.publishedFeeAmount === 0 ? '100% Free Tuition' : `PKR ${course.publishedFeeAmount?.toLocaleString()}`}
                  </strong>
                </div>
              </div>

              {course.officialLink && (
                <a
                  href={course.officialLink}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-primary btn-sm"
                  style={{ width: '100%' }}
                >
                  Official Course Registration ↗
                </a>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Firm Courses Modal */}
      {selectedFirm && (
        <div className="modal-backdrop" onClick={() => setSelectedFirm(null)}>
          <div className="modal-panel" style={{ maxWidth: '680px' }} onClick={(e) => e.stopPropagation()}>
            <button type="button" className="modal-close" onClick={() => setSelectedFirm(null)}>
              ✕
            </button>

            <span className="badge badge-featured" style={{ marginBottom: '8px' }}>
              {selectedFirm.name}
            </span>
            <h2 style={{ fontSize: '1.6rem', marginBottom: '8px' }}>Verified Courses</h2>
            <p style={{ fontSize: '0.9rem', marginBottom: '20px' }}>{selectedFirm.description}</p>

            {firmCoursesLoading ? (
              <div className="skeleton" style={{ height: '140px', width: '100%' }} />
            ) : firmCourses.length === 0 ? (
              <p style={{ color: 'var(--text-dim)' }}>No active courses recorded currently. Check official portal.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                {firmCourses.map((c) => (
                  <div key={c._id} style={{ padding: '16px', background: 'rgba(11, 19, 43, 0.7)', borderRadius: 'var(--radius-md)', border: '1px solid var(--border)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
                      <strong style={{ color: '#FFFFFF', fontSize: '1.05rem' }}>{c.title}</strong>
                      <span style={{ color: '#FCD34D', fontWeight: 700 }}>
                        {c.publishedFeeAmount === 0 ? 'Free' : `PKR ${c.publishedFeeAmount?.toLocaleString()}`}
                      </span>
                    </div>
                    <p style={{ fontSize: '0.85rem', marginBottom: '10px' }}>{c.description}</p>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginBottom: '12px' }}>
                      Duration: {c.duration} • Eligibility: {c.eligibility}
                    </div>
                    {c.officialLink && (
                      <a href={c.officialLink} target="_blank" rel="noreferrer" className="btn btn-secondary btn-sm">
                        Register Online ↗
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

