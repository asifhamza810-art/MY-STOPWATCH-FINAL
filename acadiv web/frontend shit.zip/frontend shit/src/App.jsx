import { Suspense, lazy } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import FluidBackground from './components/fluid/FluidBackground'
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'

// Core initial page
import LandingPage from './pages/LandingPage'

// Lazy-loaded dedicated route pages
const OnboardingPage = lazy(() => import('./pages/OnboardingPage'))
const AssessmentPage = lazy(() => import('./pages/AssessmentPage'))
const DiagnosticMatchPage = lazy(() => import('./pages/DiagnosticMatchPage'))
const CareerRoadmapPage = lazy(() => import('./pages/CareerRoadmapPage'))
const SkillGapPage = lazy(() => import('./pages/SkillGapPage'))
const InstitutionsPage = lazy(() => import('./pages/InstitutionsPage'))
const SkillFirmsPage = lazy(() => import('./pages/SkillFirmsPage'))
const CampusBulletinPage = lazy(() => import('./pages/CampusBulletinPage'))
const ArtifactVaultPage = lazy(() => import('./pages/ArtifactVaultPage'))
const PortfolioPage = lazy(() => import('./pages/PortfolioPage'))
const CommunityPage = lazy(() => import('./pages/CommunityPage'))
const SettingsPage = lazy(() => import('./pages/SettingsPage'))

function PageFallback() {
  return (
    <div style={{ maxWidth: '840px', margin: '60px auto', padding: '20px' }}>
      <div className="skeleton" style={{ height: '32px', width: '260px', marginBottom: '20px' }} />
      <div className="skeleton" style={{ height: '180px', width: '100%', borderRadius: 'var(--radius-lg)' }} />
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="app-layout">
          {/* Living Fluid WebGL background */}
          <FluidBackground />

          {/* Sticky responsive navigation */}
          <Navbar />

          {/* Main content container */}
          <main className="main-content">
            <Suspense fallback={<PageFallback />}>
              <Routes>
                {/* 01 — Landing Page */}
                <Route path="/" element={<LandingPage />} />

                {/* 02 — Dual-Path Onboarding */}
                <Route path="/onboarding" element={<OnboardingPage />} />

                {/* 03 — Adaptive Assessment */}
                <Route path="/assessment" element={<AssessmentPage />} />

                {/* 04 — Diagnostic Profile */}
                <Route path="/profile/match" element={<DiagnosticMatchPage />} />

                {/* 05 — Career Roadmap (3D Interactive Canvas) */}
                <Route path="/roadmap" element={<CareerRoadmapPage />} />

                {/* 06 — Skill-Gap Analysis */}
                <Route path="/skill-gap" element={<SkillGapPage />} />

                {/* 07 — Institution Explorer */}
                <Route path="/institutions" element={<InstitutionsPage />} />

                {/* 08 — Skill-Enhancing Firms */}
                <Route path="/skills" element={<SkillFirmsPage />} />

                {/* 09 — Campus Bulletin */}
                <Route path="/bulletin" element={<CampusBulletinPage />} />

                {/* 10 — Artifact Vault */}
                <Route path="/vault" element={<ArtifactVaultPage />} />

                {/* 11 — Public Portfolio & ATS CV */}
                <Route path="/portfolio/:username" element={<PortfolioPage />} />
                <Route path="/portfolio" element={<Navigate to="/portfolio/me" replace />} />

                {/* 12 — Community Hub */}
                <Route path="/community" element={<CommunityPage />} />

                {/* 13 — Settings */}
                <Route path="/settings" element={<SettingsPage />} />

                {/* Fallback */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Suspense>
          </main>

          {/* Footer with Karachi sources provenance */}
          <Footer />
        </div>
      </Router>
    </AuthProvider>
  )
}
