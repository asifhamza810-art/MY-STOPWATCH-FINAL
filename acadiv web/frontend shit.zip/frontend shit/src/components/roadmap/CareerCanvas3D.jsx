import { Suspense, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Text, Float } from '@react-three/drei'
import * as THREE from 'three'

function NodeMesh({ node, index, isSelected, onClick, onPointerOver, onPointerOut }) {
  const meshRef = useRef()
  const statusColors = {
    done: '#10B981',
    in_progress: '#0284C7',
    planned: '#64748B',
    skipped: '#94A3B8',
  }
  const color = statusColors[node.status] || '#0284C7'

  useFrame((state) => {
    if (meshRef.current) {
      if (isSelected) {
        meshRef.current.rotation.y = state.clock.elapsedTime * 0.8
      } else {
        meshRef.current.rotation.y = THREE.MathUtils.lerp(meshRef.current.rotation.y, 0, 0.05)
      }
    }
  })

  // Calculate layout coordinates in 3D space
  const x = (index - 2) * 2.6
  const y = (index % 2 === 0 ? 0.4 : -0.4)
  const z = 0

  return (
    <group position={[x, y, z]}>
      <Float speed={1.5} rotationIntensity={0.2} floatIntensity={0.3}>
        <mesh
          ref={meshRef}
          onClick={(e) => {
            e.stopPropagation()
            onClick(node)
          }}
          onPointerOver={(e) => {
            e.stopPropagation()
            onPointerOver(node)
          }}
          onPointerOut={onPointerOut}
        >
          <boxGeometry args={[1.5, 0.9, 0.3]} />
          <meshStandardMaterial
            color={isSelected ? '#0284C7' : '#1C2541'}
            emissive={isSelected ? '#0077B6' : color}
            emissiveIntensity={isSelected ? 0.7 : 0.25}
            roughness={0.2}
            metalness={0.6}
          />
        </mesh>

        {/* Milestone Indicator Sphere */}
        <mesh position={[0, 0.65, 0]}>
          <sphereGeometry args={[0.16, 16, 16]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.8} />
        </mesh>

        <Text
          position={[0, 0, 0.2]}
          fontSize={0.16}
          maxWidth={1.3}
          color="#FFFFFF"
          anchorX="center"
          anchorY="middle"
          textAlign="center"
        >
          {`Stage ${index + 1}\n${node.title ? node.title.split(':')[0] : 'Milestone'}`}
        </Text>
      </Float>
    </group>
  )
}

function ConnectorLines({ count }) {
  const points = useMemo(() => {
    const pts = []
    for (let i = 0; i < count; i++) {
      const x = (i - 2) * 2.6
      const y = (i % 2 === 0 ? 0.4 : -0.4)
      pts.push(new THREE.Vector3(x, y, 0))
    }
    return pts
  }, [count])

  if (points.length < 2) return null

  const lineGeo = new THREE.BufferGeometry().setFromPoints(points)

  return (
    <line geometry={lineGeo}>
      <lineBasicMaterial color="#0284C7" transparent opacity={0.4} linewidth={2} />
    </line>
  )
}

export default function CareerCanvas3D({ milestones = [], selectedNode, onSelectNode }) {
  const [hovered, setHovered] = useState(null)

  return (
    <div className="roadmap-canvas-wrapper" style={{ cursor: 'grab' }}>
      <div className="roadmap-overlay">
        <div style={{ fontWeight: 600, color: 'var(--text-main)', marginBottom: '4px' }}>
          3D Interactive Pathway Canvas
        </div>
        <div style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
          Drag to rotate scene • Scroll to zoom • Click nodes to view details
        </div>
      </div>

      <Canvas
        camera={{ position: [0, 0, 7.5], fov: 45 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.7} />
        <pointLight position={[10, 10, 10]} intensity={1.2} color="#38BDF8" />
        <pointLight position={[-10, -10, -5]} intensity={0.6} color="#C59B27" />

        <Suspense fallback={null}>
          <ConnectorLines count={milestones.length} />
          {milestones.map((milestone, idx) => (
            <NodeMesh
              key={milestone._id || milestone.id || idx}
              node={milestone}
              index={idx}
              isSelected={selectedNode && (selectedNode._id === milestone._id || selectedNode.title === milestone.title)}
              onClick={onSelectNode}
              onPointerOver={setHovered}
              onPointerOut={() => setHovered(null)}
            />
          ))}
          <OrbitControls
            enablePan={true}
            enableZoom={true}
            maxPolarAngle={Math.PI / 1.7}
            minPolarAngle={Math.PI / 3}
            maxDistance={12}
            minDistance={4}
          />
        </Suspense>
      </Canvas>

      {hovered && (
        <div
          style={{
            position: 'absolute',
            bottom: '16px',
            right: '16px',
            background: 'rgba(11, 19, 43, 0.92)',
            backdropFilter: 'blur(10px)',
            padding: '12px 18px',
            borderRadius: 'var(--radius-md)',
            border: '1px solid var(--border)',
            maxWidth: '320px',
            pointerEvents: 'none',
            zIndex: 10,
          }}
        >
          <div style={{ fontSize: '0.82rem', color: '#38BDF8', fontWeight: 600, textTransform: 'uppercase' }}>
            {hovered.status?.replace('_', ' ') || 'Milestone'}
          </div>
          <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#FFFFFF', marginTop: '2px' }}>
            {hovered.title}
          </div>
          {hovered.estimatedMonths && (
            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
              Duration: ~{hovered.estimatedMonths} Months
            </div>
          )}
        </div>
      )}
    </div>
  )
}

