import { Link } from 'react-router-dom'

export default function Footer() {
  return (
    <footer className="footer no-print">
      <div className="footer-inner">
        <div className="footer-brand">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--cyan)' }} />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.25rem' }}>
              ACADIV
            </span>
          </div>
          <p>
            An evidence-based educational and career-navigation platform built specifically for Pakistani students.
            Designed around Karachi colleges, universities, entry examinations, and real industry pathways.
          </p>
          <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
            <span className="badge badge-verified">Verified Karachi Data</span>
            <span className="badge badge-cyan">Zero Fabrication</span>
          </div>
        </div>

        <div className="footer-col">
          <h4>Navigation</h4>
          <ul>
            <li><Link to="/">Home & Overview</Link></li>
            <li><Link to="/onboarding">Dual-Path Onboarding</Link></li>
            <li><Link to="/assessment">RIASEC Assessment</Link></li>
            <li><Link to="/profile/match">Diagnostic Profile</Link></li>
            <li><Link to="/roadmap">3D Interactive Roadmap</Link></li>
            <li><Link to="/skill-gap">Skill-Gap Analysis</Link></li>
          </ul>
        </div>

        <div className="footer-col">
          <h4>Discovery</h4>
          <ul>
            <li><Link to="/institutions">Karachi Institutions</Link></li>
            <li><Link to="/skills">Skill Firms & Bootcamps</Link></li>
            <li><Link to="/bulletin">Campus Bulletin</Link></li>
            <li><Link to="/community">Community Discussion</Link></li>
            <li><Link to="/vault">Student Artifact Vault</Link></li>
          </ul>
        </div>

        <div className="footer-col">
          <h4>Integrity & Sources</h4>
          <ul>
            <li><a href="https://www.neduet.edu.pk/" target="_blank" rel="noreferrer">NED University</a></li>
            <li><a href="https://www.iba.edu.pk/" target="_blank" rel="noreferrer">IBA Karachi</a></li>
            <li><a href="https://khi.nu.edu.pk/" target="_blank" rel="noreferrer">FAST-NUCES Karachi</a></li>
            <li><a href="https://www.jawanpakistan.com/" target="_blank" rel="noreferrer">Jawan Pakistan</a></li>
            <li><a href="https://sindhhec.gov.pk/" target="_blank" rel="noreferrer">Sindh HEC Portal</a></li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <div>
          © {new Date().getFullYear()} Acadiv Pakistan. All institutional trademarks belong to their respective universities.
        </div>
        <div>
          Fee and admission records reflect verified public announcements. Verify final cutoffs with official university offices.
        </div>
      </div>
    </footer>
  )
}

