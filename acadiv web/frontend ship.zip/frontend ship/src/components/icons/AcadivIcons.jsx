/**
 * ACADIV CUSTOM SVG ICON FAMILY
 * Geometric, precise, consistent 1.75px stroke, rounded terminals, optical centering.
 */

export function IconBase({ size = 20, className = '', children, ...props }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`acadiv-icon ${className}`}
      aria-hidden="true"
      {...props}
    >
      {children}
    </svg>
  )
}

// 01. Explore Hub — Wayfinder compass rose
export function ExploreIcon(props) {
  return (
    <IconBase {...props}>
      <circle cx="12" cy="12" r="9" />
      <polygon points="12 4 14.5 12 12 20 9.5 12" fill="currentColor" fillOpacity="0.2" />
      <polygon points="4 12 12 9.5 20 12 12 14.5" fill="currentColor" fillOpacity="0.2" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    </IconBase>
  )
}

// 02. Assessment — Concentric target crosshair
export function AssessmentIcon(props) {
  return (
    <IconBase {...props}>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" />
      <line x1="12" y1="2" x2="12" y2="4" />
      <line x1="12" y1="20" x2="12" y2="22" />
      <line x1="2" y1="12" x2="4" y2="12" />
      <line x1="20" y1="12" x2="22" y2="12" />
    </IconBase>
  )
}

// 03. Diagnostic Match — Multi-dimensional radar/balance
export function MatchIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M12 3v18" />
      <path d="M3 12h18" />
      <polygon points="12 5 18 12 12 19 6 12" fill="currentColor" fillOpacity="0.15" />
      <circle cx="12" cy="5" r="1.5" fill="currentColor" />
      <circle cx="18" cy="12" r="1.5" fill="currentColor" />
      <circle cx="12" cy="19" r="1.5" fill="currentColor" />
      <circle cx="6" cy="12" r="1.5" fill="currentColor" />
    </IconBase>
  )
}

// 04. 3D Career Roadmap — Trajectory milestones
export function RoadmapIcon(props) {
  return (
    <IconBase {...props}>
      <circle cx="6" cy="19" r="2.5" />
      <circle cx="18" cy="5" r="2.5" fill="currentColor" fillOpacity="0.3" />
      <circle cx="12" cy="12" r="2" />
      <path d="M8.2 17.5l2.2-3.8" strokeDasharray="1.5 1.5" />
      <path d="M13.6 10.4l2.7-3.8" />
      <path d="M5 5l2 2-2 2" strokeWidth="1.25" opacity="0.6" />
    </IconBase>
  )
}

// 05. Skill Gap — Comparative diagnostic calipers
export function SkillGapIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M4 20h16" />
      <path d="M7 20V12" />
      <path d="M12 20V7" />
      <path d="M17 20V15" />
      <line x1="7" y1="9" x2="7" y2="7" strokeDasharray="1 1.5" />
      <circle cx="7" cy="6" r="1" fill="currentColor" />
      <line x1="17" y1="12" x2="17" y2="10" strokeDasharray="1 1.5" />
      <circle cx="17" cy="9" r="1" fill="currentColor" />
    </IconBase>
  )
}

// 06. Karachi Institutions — Academic colonnade
export function InstitutionsIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M3 9l9-5 9 5v2H3V9z" fill="currentColor" fillOpacity="0.15" />
      <line x1="4" y1="20" x2="20" y2="20" />
      <line x1="6" y1="11" x2="6" y2="19" />
      <line x1="10" y1="11" x2="10" y2="19" />
      <line x1="14" y1="11" x2="14" y2="19" />
      <line x1="18" y1="11" x2="18" y2="19" />
    </IconBase>
  )
}

// 07. Skill Firms — Velocity spark / energy pulse
export function SkillFirmsIcon(props) {
  return (
    <IconBase {...props}>
      <polygon points="13 2 4 14 11 14 10 22 20 10 13 10 13 2" fill="currentColor" fillOpacity="0.15" />
    </IconBase>
  )
}

// 08. Campus Bulletin — Architectural event ledger
export function BulletinIcon(props) {
  return (
    <IconBase {...props}>
      <rect x="3" y="4" width="18" height="17" rx="3" />
      <line x1="3" y1="9" x2="21" y2="9" />
      <line x1="8" y1="2" x2="8" y2="5" />
      <line x1="16" y1="2" x2="16" y2="5" />
      <circle cx="8" cy="14" r="1.25" fill="currentColor" />
      <circle cx="12" cy="14" r="1.25" fill="currentColor" />
      <circle cx="16" cy="14" r="1.25" fill="currentColor" />
    </IconBase>
  )
}

// 09. Artifact Vault — Secure student repository
export function VaultIcon(props) {
  return (
    <IconBase {...props}>
      <rect x="3" y="5" width="18" height="15" rx="2.5" />
      <circle cx="12" cy="12" r="3.5" />
      <circle cx="12" cy="12" r="1" fill="currentColor" />
      <line x1="12" y1="8.5" x2="12" y2="6.5" />
      <line x1="15.5" y1="12" x2="17.5" y2="12" />
      <line x1="8.5" y1="12" x2="6.5" y2="12" />
    </IconBase>
  )
}

// 10. Community Hub — Dialogue nodes
export function CommunityIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M21 12c0 4.4-3.6 8-8 8-1.5 0-2.9-.4-4.1-1.1L3 20l1.2-4.8C3.5 14 3 12.6 3 11c0-4.4 3.6-8 8-8s8 3.6 8 8z" />
      <circle cx="8" cy="11" r="1" fill="currentColor" />
      <circle cx="12" cy="11" r="1" fill="currentColor" />
      <circle cx="16" cy="11" r="1" fill="currentColor" />
    </IconBase>
  )
}

// 11. Portfolio & ATS CV — Credential document
export function PortfolioIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="8" y1="13" x2="16" y2="13" />
      <line x1="8" y1="17" x2="13" y2="17" />
    </IconBase>
  )
}

// 12. Settings & Privacy — Precision cog
export function SettingsIcon(props) {
  return (
    <IconBase {...props}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </IconBase>
  )
}

// Navigation Controls
export function ChevronRightIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <polyline points="9 18 15 12 9 6" />
    </IconBase>
  )
}

export function ChevronDownIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <polyline points="6 9 12 15 18 9" />
    </IconBase>
  )
}

export function MenuIcon(props) {
  return (
    <IconBase {...props}>
      <line x1="3" y1="12" x2="21" y2="12" />
      <line x1="3" y1="6" x2="21" y2="6" />
      <line x1="3" y1="18" x2="21" y2="18" />
    </IconBase>
  )
}

export function CloseIcon(props) {
  return (
    <IconBase {...props}>
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </IconBase>
  )
}

export function CollapseIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <rect x="4" y="4" width="16" height="16" rx="2" />
      <line x1="9" y1="4" x2="9" y2="20" />
      <polyline points="15 10 13 12 15 14" />
    </IconBase>
  )
}

export function ExpandIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <rect x="4" y="4" width="16" height="16" rx="2" />
      <line x1="9" y1="4" x2="9" y2="20" />
      <polyline points="13 10 15 12 13 14" />
    </IconBase>
  )
}

export function SearchIcon(props) {
  return (
    <IconBase size={18} {...props}>
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </IconBase>
  )
}

export function ExternalLinkIcon(props) {
  return (
    <IconBase size={14} {...props}>
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
      <polyline points="15 3 21 3 21 9" />
      <line x1="10" y1="14" x2="21" y2="3" />
    </IconBase>
  )
}

export function CheckIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <polyline points="20 6 9 17 4 12" />
    </IconBase>
  )
}

export function LogoutIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </IconBase>
  )
}

export function ArrowRightIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="12 5 19 12 12 19" />
    </IconBase>
  )
}

export function UploadIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </IconBase>
  )
}

// 13. Alert / Warning
export function WarningIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </IconBase>
  )
}

// 14. Location Pin
export function PinIcon(props) {
  return (
    <IconBase size={14} {...props}>
      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
      <circle cx="12" cy="10" r="3" />
    </IconBase>
  )
}

// 15. Success / Trophy
export function TrophyIcon(props) {
  return (
    <IconBase {...props}>
      <path d="M6 9H4a2 2 0 0 1-2-2V5h4" />
      <path d="M18 9h2a2 2 0 0 0 2-2V5h-4" />
      <path d="M4 5h16v6a8 8 0 0 1-16 0V5z" fill="currentColor" fillOpacity="0.1" />
      <path d="M12 15v4" />
      <path d="M8 21h8" />
    </IconBase>
  )
}

// 16. Trash / Delete
export function TrashIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </IconBase>
  )
}

// 17. Document / File
export function FileTextIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
    </IconBase>
  )
}

// 18. Folder
export function FolderIcon(props) {
  return (
    <IconBase size={18} {...props}>
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </IconBase>
  )
}

// 19. Link
export function LinkIcon(props) {
  return (
    <IconBase size={15} {...props}>
      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
    </IconBase>
  )
}

// 20. Edit
export function EditIcon(props) {
  return (
    <IconBase size={15} {...props}>
      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
    </IconBase>
  )
}

// 21. Calendar
export function CalendarIcon(props) {
  return (
    <IconBase size={16} {...props}>
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </IconBase>
  )
}

// 22. Save / Disk
export function SaveIcon(props) {
  return (
    <IconBase size={15} {...props}>
      <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
      <polyline points="17 21 17 13 7 13 7 21" />
      <polyline points="7 3 7 8 15 8" />
    </IconBase>
  )
}

// 23. Star / Sparkle
export function StarIcon(props) {
  return (
    <IconBase size={14} {...props}>
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="currentColor" fillOpacity="0.2" />
    </IconBase>
  )
}

// 24. Lock
export function LockIcon(props) {
  return (
    <IconBase size={18} {...props}>
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </IconBase>
  )
}


